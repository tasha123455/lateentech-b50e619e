
function __splitCC(p){var s=String(p||'').trim();if(!s)return{cc:'',num:''};var m=s.match(/^(\+\d{1,3})[\s-]*(.*)$/);if(m)return{cc:'\u200E'+m[1]+'\u200E',num:'\u200E'+m[2].replace(/\s+/g,'')+'\u200E'};return{cc:'',num:'\u200E'+s+'\u200E'};}

// Currency display. Keep this light: only normalize Libyan Dinar for now.
const __SYM2CODE={};
function __stripDirMarks(s){return(!s||typeof s!=='string')?s:s.replace(/[\u061C\u200E\u200F\u202A-\u202E\u2066-\u2069]/g,'').trim();}
function __normalizeCurSym(s,code){const r=__stripDirMarks(s||'');const compact=r.replace(/\s+/g,'');const cc=(code||'').toString().trim().toUpperCase();if(cc==='LYD'||compact==='ل.د'||compact==='د.ل')return'\u2066د.ل\u2069';return r;}
function __rawSym(s,code){return __normalizeCurSym(s,code);}
function __wrapArSym(s,code){const cc=(code||'').toString().toUpperCase();const r=__rawSym(s,cc);if(cc&&r){__SYM2CODE[r]=cc;const old=__stripDirMarks(s||'');if(old)__SYM2CODE[old]=cc;}return r;}
function __escH(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function __money(n,sym,code){const a=parseFloat(n||0).toFixed(2);const cc=(code||__SYM2CODE[__stripDirMarks(sym||'')]||'').toString().toUpperCase();const r=__stripDirMarks(__rawSym(sym||'£',cc));const isAr=(typeof document!=='undefined'&&document.documentElement.lang==='ar');return isAr?(a+r):(cc?(a+' '+cc):(r+a));}
function __moneyH(n,sym,code){const a=parseFloat(n||0).toFixed(2);const cc=(code||__SYM2CODE[__stripDirMarks(sym||'')]||'').toString().toUpperCase();const r=__stripDirMarks(__rawSym(sym||'£',cc));const isAr=(typeof document!=='undefined'&&document.documentElement.lang==='ar');const symHtml='<span class="cur-sym">'+__escH(r)+'</span>';const codeHtml=cc?'<span class="cur-sym">'+__escH(cc)+'</span>':'';return isAr?(__escH(a)+symHtml):(cc?(__escH(a)+' '+codeHtml):(symHtml+__escH(a)));}
if(typeof window!=='undefined'){window.__money=__money;window.__moneyH=__moneyH;window.__rawSym=__rawSym;}

/* Charts */
const __AR_LBL={Sun:'الأحد',Mon:'الإثنين',Tue:'الثلاثاء',Wed:'الأربعاء',Thu:'الخميس',Fri:'الجمعة',Sat:'السبت',Jan:'يناير',Feb:'فبراير',Mar:'مارس',Apr:'أبريل',May:'مايو',Jun:'يونيو',Jul:'يوليو',Aug:'أغسطس',Sep:'سبتمبر',Oct:'أكتوبر',Nov:'نوفمبر',Dec:'ديسمبر'};
const __ar=()=>document.documentElement.lang==='ar';
const __tlbl=v=>(__ar()&&__AR_LBL[v])?__AR_LBL[v]:v;
window.addEventListener('lateen-lang',()=>{try{if(typeof loadProducts==='function')loadProducts();if(typeof loadOrders==='function')loadOrders();if(typeof buildMainChart==='function')buildMainChart();if(typeof renderVariantGroups==='function')renderVariantGroups();if(typeof refreshProfile==='function')refreshProfile();}catch(e){}});
const chartData={revenue:{D:{labels:[],sub:[],values:[]},M:{labels:[],sub:[],values:[]},Y:{labels:[],sub:[],values:[]}},pieces:{D:{labels:[],sub:[],values:[]},M:{labels:[],sub:[],values:[]},Y:{labels:[],sub:[],values:[]}}};
const analyticsData={D:{ok:0,fail:0},M:{ok:0,fail:0},Y:{ok:0,fail:0}};
let currentMetric='revenue',currentPeriod='D',mainChart,ringChart;
const __VIS={D:7,M:6,Y:6};
function __pad(n){return n<10?'0'+n:''+n;}
function __ddmmyyyy(d){return __pad(d.getDate())+'/'+__pad(d.getMonth()+1)+'/'+d.getFullYear();}
function __bindChartPan(canvas,getChart){if(!canvas||canvas.__panBound)return;canvas.__panBound=true;let sx=0,sy=0,lx=0,decided=0,active=false;const onStart=(e)=>{if(!e.touches||e.touches.length!==1){active=false;decided=0;return;}const t=e.touches[0];sx=lx=t.clientX;sy=t.clientY;decided=0;active=true;};const onMove=(e)=>{if(!active||!e.touches||e.touches.length!==1)return;const t=e.touches[0];const dx=t.clientX-sx,dy=t.clientY-sy;if(!decided){if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)*1.2){decided=1;}else if(Math.abs(dy)>8){decided=2;active=false;return;}else{return;}}if(decided===1){e.preventDefault();const ch=getChart&&getChart();if(ch&&typeof ch.pan==='function'){const d=t.clientX-lx;if(d)ch.pan({x:d},undefined,'none');}lx=t.clientX;}};const onEnd=()=>{active=false;decided=0;};canvas.addEventListener('touchstart',onStart,{passive:true});canvas.addEventListener('touchmove',onMove,{passive:false});canvas.addEventListener('touchend',onEnd,{passive:true});canvas.addEventListener('touchcancel',onEnd,{passive:true});}

function buildMainChart(){
  if(mainChart){try{mainChart.destroy();}catch(e){}mainChart=null;}
  const canvas=document.getElementById('mainChart');if(!canvas||typeof Chart==='undefined')return;
  try{const __existing=Chart.getChart(canvas);if(__existing)__existing.destroy();}catch(e){}
  try{if(Chart.instances){Object.keys(Chart.instances).forEach(k=>{const inst=Chart.instances[k];if(inst&&inst.canvas===canvas){try{inst.destroy();}catch(e){}}});}}catch(e){}
  const d=chartData[currentMetric][currentPeriod];
  const labels=d.labels.map(v=>__tlbl(v));
  const subs=d.sub||[];
  const n=d.values.length;const vis=Math.min(__VIS[currentPeriod]||7,n);
  const maxIdx=n-1;const minIdx=Math.max(0,n-vis);
  const hasZoom=!!(Chart.registry&&Chart.registry.plugins&&(()=>{try{return Chart.registry.plugins.get('zoom');}catch(e){return false;}})());
  const __curRange=vis;
  const __guardZoomOut=({chart})=>{const sx=chart.scales.x;if((sx.max-sx.min)>=__curRange){sx.options.min=minIdx;sx.options.max=maxIdx;chart.update('none');return false;}};
  const zoomOpts=hasZoom?{zoom:{pan:{enabled:true,mode:'x',threshold:10},zoom:{wheel:{enabled:true,speed:0.05,modifierKey:null},pinch:{enabled:false},mode:'x',onZoom:__guardZoomOut,onZoomStart:({chart,event})=>{if(event&&event.deltaY!=null&&event.deltaY>0)return false;}},limits:{x:{min:-0.5,max:n-0.5,minRange:1,maxRange:__curRange}}}}:{};
  const __color='#34c77b';const ctx2d=canvas.getContext('2d');const grad=ctx2d.createLinearGradient(0,0,0,canvas.height||220);grad.addColorStop(0,__color+'66');grad.addColorStop(1,__color+'00');
  mainChart=new Chart(canvas,{type:'line',data:{labels,datasets:[{data:d.values,borderColor:__color,backgroundColor:grad,fill:true,tension:0.4,cubicInterpolationMode:'monotone',borderWidth:2.5,pointRadius:3,pointHoverRadius:6,pointHitRadius:8,pointBackgroundColor:__color,pointBorderColor:'#fff',pointBorderWidth:1.5,spanGaps:true}]},options:{responsive:true,maintainAspectRatio:false,devicePixelRatio:Math.min(window.devicePixelRatio||1,2),animation:false,transitions:{zoom:{animation:{duration:0}},pan:{animation:{duration:0}},active:{animation:{duration:0}},show:{animation:{duration:0}},hide:{animation:{duration:0}}},interaction:{mode:'point',intersect:true},plugins:Object.assign({legend:{display:false},decimation:{enabled:true,algorithm:'lttb',samples:80},tooltip:{animation:false,displayColors:false,padding:10,titleFont:{size:12,weight:'600'},bodyFont:{size:12},callbacks:{title:items=>{if(!items||!items[0])return '';const i=items[0].dataIndex;const lab=__tlbl(d.labels[i]||'');const s=subs[i]||'';return s?lab+' · '+s:lab;},label:ctx=>currentMetric==='revenue'?' '+__money(ctx.raw,window.__bizSelSym?window.__bizSelSym():'£',window.__bizWalletCur):' '+ctx.raw+' pcs'}}},zoomOpts),scales:{x:{min:minIdx,max:maxIdx,grid:{display:false},ticks:{font:{size:11},color:'#5e5c58',maxRotation:0,autoSkip:true,maxTicksLimit:vis+1}},y:{beginAtZero:true,grace:'5%',grid:{color:'rgba(255,255,255,0.04)'},ticks:{font:{size:10},color:'#5e5c58',maxTicksLimit:5,callback:v=>currentMetric==='revenue'?__money(v,window.__bizSelSym?window.__bizSelSym():'£',window.__bizWalletCur):v}}}}});canvas.style.touchAction='pan-y';if(canvas.parentElement)canvas.parentElement.style.touchAction='pan-y';__bindChartPan(canvas,()=>mainChart);
}
let __ringShowFail=false;
function __ringUpdateLabel(){const a=analyticsData[currentPeriod];const total=a.ok+a.fail;const okPct=total>0?Math.round((a.ok/total)*100):0;const failPct=total>0?100-okPct:0;const pctEl=document.getElementById('ring-pct');const subEl=document.getElementById('ring-sub');if(pctEl)pctEl.textContent=(__ringShowFail?failPct:okPct)+'%';if(subEl)subEl.textContent=__ringShowFail?'failed':'success';}
function buildRingChart(){__ringShowFail=false;const a=analyticsData[currentPeriod];const total=a.ok+a.fail;const okPct=total>0?Math.round((a.ok/total)*100):0;const failPct=total>0?100-okPct:0;document.getElementById('leg-ok').textContent=a.ok.toLocaleString();document.getElementById('leg-fail').textContent=a.fail.toLocaleString();__ringUpdateLabel();if(typeof Chart==='undefined')return;if(ringChart)ringChart.destroy();const __ringColors=total>0?['#35c98f','#e2685f']:['#2a2a2a','#2a2a2a'];ringChart=new Chart(document.getElementById('ringChart'),{type:'doughnut',data:{datasets:[{data:total>0?[okPct,failPct]:[0,100],backgroundColor:__ringColors,hoverBackgroundColor:__ringColors,borderWidth:0,hoverOffset:0,hoverBorderWidth:0}]},options:{cutout:'72%',responsive:false,events:[],plugins:{legend:{display:false},tooltip:{enabled:false}},animation:{duration:500}}});}
function switchMetric(m,el){currentMetric=m;document.querySelectorAll('.ctoggle').forEach(b=>b.classList.remove('active'));el.classList.add('active');buildMainChart();}
function switchPeriod(p,el){currentPeriod=p;document.querySelectorAll('.ptab').forEach(b=>b.classList.remove('active'));el.classList.add('active');buildMainChart();buildRingChart();}
(function(){
  const ringWrap=document.getElementById('ringWrap');
  const legRowOk=document.getElementById('leg-row-ok');
  const legRowFail=document.getElementById('leg-row-fail');
  if(ringWrap)ringWrap.addEventListener('click',()=>{__ringShowFail=!__ringShowFail;__ringUpdateLabel();});
  if(legRowOk)legRowOk.addEventListener('click',e=>{e.stopPropagation();__ringShowFail=false;__ringUpdateLabel();});
  if(legRowFail)legRowFail.addEventListener('click',e=>{e.stopPropagation();__ringShowFail=true;__ringUpdateLabel();});
})();

/* Nav */
function goTo(pageId){document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));document.getElementById(pageId).classList.add('active');const navMap={'pg-home':'nav-home','pg-products':'nav-products','pg-orders':'nav-orders'};document.querySelectorAll('.nav-item').forEach(n=>{n.classList.remove('active');n.querySelectorAll('svg').forEach(s=>s.setAttribute('stroke','var(--color-text-secondary)'));n.querySelector('.nav-label').style.color='';});if(navMap[pageId]){const nav=document.getElementById(navMap[pageId]);nav.classList.add('active');nav.querySelectorAll('svg').forEach(s=>s.setAttribute('stroke','#34c77b'));nav.querySelector('.nav-label').style.color='#34c77b';}if(pageId==='pg-products'){renderProducts();renderPhotoGrid();}if(pageId==='pg-orders'){updateSummary();applyFilters();}if(pageId==='pg-notif')document.getElementById('notif-dot').style.display='none';}
function openMenu(){document.getElementById('menu-overlay').classList.add('open');document.body.style.overflow='hidden';document.documentElement.style.overflow='hidden';}
function closeMenu(){document.getElementById('menu-overlay').classList.remove('open');document.body.style.overflow='';document.documentElement.style.overflow='';}
function openPayout(){document.getElementById('payout-overlay').classList.add('open');if(typeof bdRenderBreakdown==='function')bdRenderBreakdown();}
function closePayout(){document.getElementById('payout-overlay').classList.remove('open');}

/* ── Breakdown modal (Day/Month/Year filtered financial breakdown) ── */
const __bdDays=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const __bdMonths=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
let __bdAllTime={earnings:0,pieces:0,marketers:0,succeeded:0,failed:0};
const __bdSelected={day:null,month:null,year:null};
// Single source of truth for what counts as an "active" marketer order —
// pending, approved, or confirmed (i.e. approved-but-not-yet-delivered).
// This is the exact same status set the marketer app's live
// active_marketers_count(s) RPC uses, so every "Active marketers" figure
// across both dashboards (breakdown boxes, per-product Marketer info tile)
// always agrees.
const __ACTIVE_MKT_STATUSES=new Set(['pending','approved','confirmed']);
function __bdFilterOrders(sel){return (orders||[]).concat(__pendingActiveStubs||[]).filter(o=>{const c=o._createdAt;if(!c)return false;if(sel.day&&__bdDays[c.getDay()]!==sel.day)return false;if(sel.month&&__bdMonths[c.getMonth()]!==sel.month)return false;if(sel.year&&String(c.getFullYear())!==sel.year)return false;return true;});}
function __bdGenerateData(sel){if(!sel.day&&!sel.month&&!sel.year)return __bdAllTime;const list=__bdFilterOrders(sel);let earnings=0,pieces=0,succeeded=0,failed=0;const mset=new Set();list.forEach(o=>{if(o._status==='delivered'){earnings+=(o.price*o.qty)-o.commission-o.platformFee;pieces+=o.qty;succeeded++;}if(o._status==='cancelled')failed++;if(o.marketerId&&__ACTIVE_MKT_STATUSES.has(o._status))mset.add(o.marketerId);});return{earnings,pieces,marketers:mset.size,succeeded,failed};}
function __ordFrac(n){if(n===1)return'طلبيه واحده';if(n===2)return'طلبيتين';return n+' طلبيات';}
function bdRenderBreakdown(){const data=__bdGenerateData(__bdSelected);const mEl=document.getElementById('bd-marketers-val');if(mEl)mEl.textContent=data.marketers;const grid=document.getElementById('bd-grid');if(!grid)return;const total=data.succeeded+data.failed;const succPct=total>0?Math.round((data.succeeded/total)*100):0;const failPct=total>0?Math.round((data.failed/total)*100):0;const sym=(typeof window.__bizSelSym==='function')?window.__bizSelSym():'$';const ar=__ar();const succLbl=ar?'الطلبات تم تسليمها':'Succeeded';const failLbl=ar?'الطلبات لم يتم تسليمها':'Failed';const succSub=ar?('من أصل '+__ordFrac(total)):(succPct+'%');const failSub=ar?('من أصل '+__ordFrac(total)):(failPct+'%');const piecesLbl=ar?'قطع تم بيعها':'Pieces sold';const netLbl=ar?'صافي الأرباح منذ إنشاء الحساب':'Net earnings';grid.innerHTML=`
    <div class="bd-box"><div class="bd-box-label" data-no-i18n>${netLbl}</div><div class="bd-box-value">${__moneyH(data.earnings,sym,window.__bizWalletCur)}</div></div>
    <div class="bd-box"><div class="bd-box-label" data-no-i18n>${piecesLbl}</div><div class="bd-box-value">${data.pieces}</div></div>
    <div class="bd-box"><div class="bd-box-label" data-no-i18n>${succLbl}</div><div class="bd-box-value green" data-no-i18n>${data.succeeded} <span style="font-size:12px;color:var(--color-text-tertiary);font-weight:500;">(${succSub})</span></div></div>
    <div class="bd-box"><div class="bd-box-label" data-no-i18n>${failLbl}</div><div class="bd-box-value red" data-no-i18n>${data.failed} <span style="font-size:12px;color:var(--color-text-tertiary);font-weight:500;">(${failSub})</span></div></div>
  `;}
const __bdRangeMeta={daily:{key:'day',defaultLabel:'Day',list:null},monthly:{key:'month',defaultLabel:'Month',list:null},yearly:{key:'year',defaultLabel:'Year',list:null}};
function __bdUpdateTabLabel(filterKey){const rangeName=Object.keys(__bdRangeMeta).find(r=>__bdRangeMeta[r].key===filterKey);const tab=document.querySelector(`.bd-range-tab[data-range="${rangeName}"]`);if(!tab)return;const val=__bdSelected[filterKey];tab.innerHTML=(val?val:__bdRangeMeta[rangeName].defaultLabel)+' <span class="bd-chev">▾</span>';tab.classList.toggle('active',!!val);__bdUpdateAllTabState();}
function __bdUpdateAllTabState(){const allTab=document.querySelector('.bd-range-tab[data-range="all"]');if(!allTab)return;const anySelected=__bdSelected.day||__bdSelected.month||__bdSelected.year;allTab.classList.toggle('active',!anySelected);}
function __bdCloseDropdown(rangeName){const meta=__bdRangeMeta[rangeName];if(!meta||!meta.list)return;meta.list.classList.remove('open');const tab=document.querySelector(`.bd-range-tab[data-range="${rangeName}"]`);if(tab)tab.classList.remove('open');}
function __bdCloseAllDropdowns(){Object.keys(__bdRangeMeta).forEach(r=>__bdCloseDropdown(r));}
function __bdBuildDropdown(listEl,keys,filterKey,rangeName){if(!listEl)return;listEl.innerHTML='';const clearItem=document.createElement('div');clearItem.className='bd-dd-item clear';clearItem.textContent='Clear selection';clearItem.addEventListener('click',e=>{e.stopPropagation();__bdSelected[filterKey]=null;__bdUpdateTabLabel(filterKey);__bdCloseDropdown(rangeName);bdRenderBreakdown();});listEl.appendChild(clearItem);keys.forEach(key=>{const item=document.createElement('div');item.className='bd-dd-item';item.textContent=key;item.addEventListener('click',e=>{e.stopPropagation();__bdSelected[filterKey]=key;__bdUpdateTabLabel(filterKey);__bdCloseDropdown(rangeName);bdRenderBreakdown();});listEl.appendChild(item);});}
function bdTabClick(range,tabEl){if(range==='all'){__bdCloseAllDropdowns();__bdSelected.day=null;__bdSelected.month=null;__bdSelected.year=null;Object.keys(__bdRangeMeta).forEach(r=>{const t=document.querySelector(`.bd-range-tab[data-range="${r}"]`);if(t){t.innerHTML=__bdRangeMeta[r].defaultLabel+' <span class="bd-chev">▾</span>';t.classList.remove('active');}});tabEl.classList.add('active');bdRenderBreakdown();return;}const meta=__bdRangeMeta[range];if(!meta||!meta.list)return;const isOpen=meta.list.classList.contains('open');Object.keys(__bdRangeMeta).forEach(r=>{if(r!==range)__bdCloseDropdown(r);});if(isOpen){__bdCloseDropdown(range);}else{meta.list.classList.add('open');tabEl.classList.add('open');}}
function __bdInit(){__bdRangeMeta.daily.list=document.getElementById('bd-daily-list');__bdRangeMeta.monthly.list=document.getElementById('bd-monthly-list');__bdRangeMeta.yearly.list=document.getElementById('bd-yearly-list');if(!__bdRangeMeta.daily.list)return;const curYear=new Date().getFullYear();const yrs=[curYear-2,curYear-1,curYear].map(String);__bdBuildDropdown(__bdRangeMeta.daily.list,__bdDays,'day','daily');__bdBuildDropdown(__bdRangeMeta.monthly.list,__bdMonths,'month','monthly');__bdBuildDropdown(__bdRangeMeta.yearly.list,yrs,'year','yearly');document.addEventListener('click',e=>{if(!e.target.closest('.bd-range-tab')&&!e.target.closest('.bd-dropdown-list'))__bdCloseAllDropdowns();});bdRenderBreakdown();}
__bdInit();

/* Products */
const PLATFORM_FEE_RATE=0.05;
const CURRENCIES=[{code:'AED',name:'UAE Dirham',symbol:'د.إ',flag:'🇦🇪'},{code:'AFN',name:'Afghan Afghani',symbol:'؋',flag:'🇦🇫'},{code:'ALL',name:'Albanian Lek',symbol:'L',flag:'🇦🇱'},{code:'AMD',name:'Armenian Dram',symbol:'֏',flag:'🇦🇲'},{code:'ANG',name:'Netherlands Antillean Guilder',symbol:'ƒ',flag:'🇨🇼'},{code:'AOA',name:'Angolan Kwanza',symbol:'Kz',flag:'🇦🇴'},{code:'ARS',name:'Argentine Peso',symbol:'$',flag:'🇦🇷'},{code:'AUD',name:'Australian Dollar',symbol:'A$',flag:'🇦🇺'},{code:'AWG',name:'Aruban Florin',symbol:'ƒ',flag:'🇦🇼'},{code:'AZN',name:'Azerbaijani Manat',symbol:'₼',flag:'🇦🇿'},{code:'BAM',name:'Bosnia-Herzegovina Convertible Mark',symbol:'KM',flag:'🇧🇦'},{code:'BBD',name:'Barbadian Dollar',symbol:'$',flag:'🇧🇧'},{code:'BDT',name:'Bangladeshi Taka',symbol:'৳',flag:'🇧🇩'},{code:'BGN',name:'Bulgarian Lev',symbol:'лв',flag:'🇧🇬'},{code:'BHD',name:'Bahraini Dinar',symbol:'.د.ب',flag:'🇧🇭'},{code:'BIF',name:'Burundian Franc',symbol:'Fr',flag:'🇧🇮'},{code:'BMD',name:'Bermudian Dollar',symbol:'$',flag:'🇧🇲'},{code:'BND',name:'Brunei Dollar',symbol:'B$',flag:'🇧🇳'},{code:'BOB',name:'Bolivian Boliviano',symbol:'Bs',flag:'🇧🇴'},{code:'BRL',name:'Brazilian Real',symbol:'R$',flag:'🇧🇷'},{code:'BSD',name:'Bahamian Dollar',symbol:'$',flag:'🇧🇸'},{code:'BTN',name:'Bhutanese Ngultrum',symbol:'Nu.',flag:'🇧🇹'},{code:'BWP',name:'Botswanan Pula',symbol:'P',flag:'🇧🇼'},{code:'BYN',name:'Belarusian Ruble',symbol:'Br',flag:'🇧🇾'},{code:'BZD',name:'Belize Dollar',symbol:'BZ$',flag:'🇧🇿'},{code:'CAD',name:'Canadian Dollar',symbol:'C$',flag:'🇨🇦'},{code:'CDF',name:'Congolese Franc',symbol:'Fr',flag:'🇨🇩'},{code:'CHF',name:'Swiss Franc',symbol:'Fr',flag:'🇨🇭'},{code:'CLP',name:'Chilean Peso',symbol:'$',flag:'🇨🇱'},{code:'CNY',name:'Chinese Yuan',symbol:'¥',flag:'🇨🇳'},{code:'COP',name:'Colombian Peso',symbol:'$',flag:'🇨🇴'},{code:'CRC',name:'Costa Rican Colón',symbol:'₡',flag:'🇨🇷'},{code:'CUP',name:'Cuban Peso',symbol:'$',flag:'🇨🇺'},{code:'CVE',name:'Cape Verdean Escudo',symbol:'$',flag:'🇨🇻'},{code:'CZK',name:'Czech Koruna',symbol:'Kč',flag:'🇨🇿'},{code:'DJF',name:'Djiboutian Franc',symbol:'Fr',flag:'🇩🇯'},{code:'DKK',name:'Danish Krone',symbol:'kr',flag:'🇩🇰'},{code:'DOP',name:'Dominican Peso',symbol:'RD$',flag:'🇩🇴'},{code:'DZD',name:'Algerian Dinar',symbol:'دج',flag:'🇩🇿'},{code:'EGP',name:'Egyptian Pound',symbol:'E£',flag:'🇪🇬'},{code:'ERN',name:'Eritrean Nakfa',symbol:'Nfk',flag:'🇪🇷'},{code:'ETB',name:'Ethiopian Birr',symbol:'Br',flag:'🇪🇹'},{code:'EUR',name:'Euro',symbol:'€',flag:'🇪🇺'},{code:'FJD',name:'Fijian Dollar',symbol:'FJ$',flag:'🇫🇯'},{code:'FKP',name:'Falkland Islands Pound',symbol:'£',flag:'🇫🇰'},{code:'GBP',name:'British Pound',symbol:'£',flag:'🇬🇧'},{code:'GEL',name:'Georgian Lari',symbol:'₾',flag:'🇬🇪'},{code:'GHS',name:'Ghanaian Cedi',symbol:'₵',flag:'🇬🇭'},{code:'GIP',name:'Gibraltar Pound',symbol:'£',flag:'🇬🇮'},{code:'GMD',name:'Gambian Dalasi',symbol:'D',flag:'🇬🇲'},{code:'GNF',name:'Guinean Franc',symbol:'Fr',flag:'🇬🇳'},{code:'GTQ',name:'Guatemalan Quetzal',symbol:'Q',flag:'🇬🇹'},{code:'GYD',name:'Guyanese Dollar',symbol:'$',flag:'🇬🇾'},{code:'HKD',name:'Hong Kong Dollar',symbol:'HK$',flag:'🇭🇰'},{code:'HNL',name:'Honduran Lempira',symbol:'L',flag:'🇭🇳'},{code:'HRK',name:'Croatian Kuna',symbol:'kn',flag:'🇭🇷'},{code:'HTG',name:'Haitian Gourde',symbol:'G',flag:'🇭🇹'},{code:'HUF',name:'Hungarian Forint',symbol:'Ft',flag:'🇭🇺'},{code:'IDR',name:'Indonesian Rupiah',symbol:'Rp',flag:'🇮🇩'},{code:'ILS',name:'Israeli New Shekel',symbol:'₪',flag:'🇮🇱'},{code:'INR',name:'Indian Rupee',symbol:'₹',flag:'🇮🇳'},{code:'IQD',name:'Iraqi Dinar',symbol:'ع.د',flag:'🇮🇶'},{code:'IRR',name:'Iranian Rial',symbol:'﷼',flag:'🇮🇷'},{code:'ISK',name:'Icelandic Króna',symbol:'kr',flag:'🇮🇸'},{code:'JMD',name:'Jamaican Dollar',symbol:'J$',flag:'🇯🇲'},{code:'JOD',name:'Jordanian Dinar',symbol:'د.أ',flag:'🇯🇴'},{code:'JPY',name:'Japanese Yen',symbol:'¥',flag:'🇯🇵'},{code:'KES',name:'Kenyan Shilling',symbol:'KSh',flag:'🇰🇪'},{code:'KGS',name:'Kyrgystani Som',symbol:'с',flag:'🇰🇬'},{code:'KHR',name:'Cambodian Riel',symbol:'៛',flag:'🇰🇭'},{code:'KMF',name:'Comorian Franc',symbol:'Fr',flag:'🇰🇲'},{code:'KPW',name:'North Korean Won',symbol:'₩',flag:'🇰🇵'},{code:'KRW',name:'South Korean Won',symbol:'₩',flag:'🇰🇷'},{code:'KWD',name:'Kuwaiti Dinar',symbol:'د.ك',flag:'🇰🇼'},{code:'KYD',name:'Cayman Islands Dollar',symbol:'$',flag:'🇰🇾'},{code:'KZT',name:'Kazakhstani Tenge',symbol:'₸',flag:'🇰🇿'},{code:'LAK',name:'Laotian Kip',symbol:'₭',flag:'🇱🇦'},{code:'LBP',name:'Lebanese Pound',symbol:'ل.ل',flag:'🇱🇧'},{code:'LKR',name:'Sri Lankan Rupee',symbol:'Rs',flag:'🇱🇰'},{code:'LRD',name:'Liberian Dollar',symbol:'L$',flag:'🇱🇷'},{code:'LSL',name:'Lesotho Loti',symbol:'L',flag:'🇱🇸'},{code:'LYD',name:'Libyan Dinar',symbol:'د.ل',flag:'🇱🇾'},{code:'MAD',name:'Moroccan Dirham',symbol:'د.م.',flag:'🇲🇦'},{code:'MDL',name:'Moldovan Leu',symbol:'L',flag:'🇲🇩'},{code:'MGA',name:'Malagasy Ariary',symbol:'Ar',flag:'🇲🇬'},{code:'MKD',name:'Macedonian Denar',symbol:'ден',flag:'🇲🇰'},{code:'MMK',name:'Myanmar Kyat',symbol:'K',flag:'🇲🇲'},{code:'MNT',name:'Mongolian Tugrik',symbol:'₮',flag:'🇲🇳'},{code:'MOP',name:'Macanese Pataca',symbol:'P',flag:'🇲🇴'},{code:'MRU',name:'Mauritanian Ouguiya',symbol:'UM',flag:'🇲🇷'},{code:'MUR',name:'Mauritian Rupee',symbol:'₨',flag:'🇲🇺'},{code:'MVR',name:'Maldivian Rufiyaa',symbol:'Rf',flag:'🇲🇻'},{code:'MWK',name:'Malawian Kwacha',symbol:'MK',flag:'🇲🇼'},{code:'MXN',name:'Mexican Peso',symbol:'$',flag:'🇲🇽'},{code:'MYR',name:'Malaysian Ringgit',symbol:'RM',flag:'🇲🇾'},{code:'MZN',name:'Mozambican Metical',symbol:'MT',flag:'🇲🇿'},{code:'NAD',name:'Namibian Dollar',symbol:'N$',flag:'🇳🇦'},{code:'NGN',name:'Nigerian Naira',symbol:'₦',flag:'🇳🇬'},{code:'NIO',name:'Nicaraguan Córdoba',symbol:'C$',flag:'🇳🇮'},{code:'NOK',name:'Norwegian Krone',symbol:'kr',flag:'🇳🇴'},{code:'NPR',name:'Nepalese Rupee',symbol:'₨',flag:'🇳🇵'},{code:'NZD',name:'New Zealand Dollar',symbol:'NZ$',flag:'🇳🇿'},{code:'OMR',name:'Omani Rial',symbol:'ر.ع.',flag:'🇴🇲'},{code:'PAB',name:'Panamanian Balboa',symbol:'B/.',flag:'🇵🇦'},{code:'PEN',name:'Peruvian Sol',symbol:'S/',flag:'🇵🇪'},{code:'PGK',name:'Papua New Guinean Kina',symbol:'K',flag:'🇵🇬'},{code:'PHP',name:'Philippine Peso',symbol:'₱',flag:'🇵🇭'},{code:'PKR',name:'Pakistani Rupee',symbol:'₨',flag:'🇵🇰'},{code:'PLN',name:'Polish Złoty',symbol:'zł',flag:'🇵🇱'},{code:'PYG',name:'Paraguayan Guaraní',symbol:'₲',flag:'🇵🇾'},{code:'QAR',name:'Qatari Riyal',symbol:'ر.ق',flag:'🇶🇦'},{code:'RON',name:'Romanian Leu',symbol:'lei',flag:'🇷🇴'},{code:'RSD',name:'Serbian Dinar',symbol:'дин',flag:'🇷🇸'},{code:'RUB',name:'Russian Ruble',symbol:'₽',flag:'🇷🇺'},{code:'RWF',name:'Rwandan Franc',symbol:'Fr',flag:'🇷🇼'},{code:'SAR',name:'Saudi Riyal',symbol:'﷼',flag:'🇸🇦'},{code:'SBD',name:'Solomon Islands Dollar',symbol:'$',flag:'🇸🇧'},{code:'SCR',name:'Seychellois Rupee',symbol:'₨',flag:'🇸🇨'},{code:'SDG',name:'Sudanese Pound',symbol:'ج.س.',flag:'🇸🇩'},{code:'SEK',name:'Swedish Krona',symbol:'kr',flag:'🇸🇪'},{code:'SGD',name:'Singapore Dollar',symbol:'S$',flag:'🇸🇬'},{code:'SHP',name:'Saint Helena Pound',symbol:'£',flag:'🇸🇭'},{code:'SLE',name:'Sierra Leonean Leone',symbol:'Le',flag:'🇸🇱'},{code:'SOS',name:'Somali Shilling',symbol:'Sh',flag:'🇸🇴'},{code:'SRD',name:'Surinamese Dollar',symbol:'$',flag:'🇸🇷'},{code:'SSP',name:'South Sudanese Pound',symbol:'£',flag:'🇸🇸'},{code:'STN',name:'São Tomé and Príncipe Dobra',symbol:'Db',flag:'🇸🇹'},{code:'SVC',name:'Salvadoran Colón',symbol:'₡',flag:'🇸🇻'},{code:'SYP',name:'Syrian Pound',symbol:'£',flag:'🇸🇾'},{code:'SZL',name:'Eswatini Lilangeni',symbol:'L',flag:'🇸🇿'},{code:'THB',name:'Thai Baht',symbol:'฿',flag:'🇹🇭'},{code:'TJS',name:'Tajikistani Somoni',symbol:'ЅМ',flag:'🇹🇯'},{code:'TMT',name:'Turkmenistani Manat',symbol:'m',flag:'🇹🇲'},{code:'TND',name:'Tunisian Dinar',symbol:'د.ت',flag:'🇹🇳'},{code:'TOP',name:'Tongan Paʻanga',symbol:'T$',flag:'🇹🇴'},{code:'TRY',name:'Turkish Lira',symbol:'₺',flag:'🇹🇷'},{code:'TTD',name:'Trinidad and Tobago Dollar',symbol:'TT$',flag:'🇹🇹'},{code:'TWD',name:'New Taiwan Dollar',symbol:'NT$',flag:'🇹🇼'},{code:'TZS',name:'Tanzanian Shilling',symbol:'Sh',flag:'🇹🇿'},{code:'UAH',name:'Ukrainian Hryvnia',symbol:'₴',flag:'🇺🇦'},{code:'UGX',name:'Ugandan Shilling',symbol:'Sh',flag:'🇺🇬'},{code:'USD',name:'US Dollar',symbol:'$',flag:'🇺🇸'},{code:'UYU',name:'Uruguayan Peso',symbol:'$U',flag:'🇺🇾'},{code:'UZS',name:'Uzbekistani Som',symbol:'soʻm',flag:'🇺🇿'},{code:'VES',name:'Venezuelan Bolívar',symbol:'Bs.S',flag:'🇻🇪'},{code:'VND',name:'Vietnamese Dong',symbol:'₫',flag:'🇻🇳'},{code:'VUV',name:'Vanuatu Vatu',symbol:'Vt',flag:'🇻🇺'},{code:'WST',name:'Samoan Tala',symbol:'T',flag:'🇼🇸'},{code:'XAF',name:'Central African CFA Franc',symbol:'Fr',flag:'🌍'},{code:'XCD',name:'East Caribbean Dollar',symbol:'EC$',flag:'🌎'},{code:'XOF',name:'West African CFA Franc',symbol:'Fr',flag:'🌍'},{code:'XPF',name:'CFP Franc',symbol:'Fr',flag:'🌏'},{code:'YER',name:'Yemeni Rial',symbol:'﷼',flag:'🇾🇪'},{code:'ZAR',name:'South African Rand',symbol:'R',flag:'🇿🇦'},{code:'ZMW',name:'Zambian Kwacha',symbol:'ZK',flag:'🇿🇲'},{code:'ZWL',name:'Zimbabwean Dollar',symbol:'Z$',flag:'🇿🇼'}];
// Normalize stored/displayed Arabic-script currency symbols once, without invisible wrappers.
(function(){CURRENCIES.forEach(c=>{c.symbol=__wrapArSym(c.symbol,c.code);});})();
const COUNTRIES=[{code:'AF',name:'Afghanistan',flag:'🇦🇫'},{code:'AL',name:'Albania',flag:'🇦🇱'},{code:'DZ',name:'Algeria',flag:'🇩🇿'},{code:'AD',name:'Andorra',flag:'🇦🇩'},{code:'AO',name:'Angola',flag:'🇦🇴'},{code:'AG',name:'Antigua and Barbuda',flag:'🇦🇬'},{code:'AR',name:'Argentina',flag:'🇦🇷'},{code:'AM',name:'Armenia',flag:'🇦🇲'},{code:'AU',name:'Australia',flag:'🇦🇺'},{code:'AT',name:'Austria',flag:'🇦🇹'},{code:'AZ',name:'Azerbaijan',flag:'🇦🇿'},{code:'BS',name:'Bahamas',flag:'🇧🇸'},{code:'BH',name:'Bahrain',flag:'🇧🇭'},{code:'BD',name:'Bangladesh',flag:'🇧🇩'},{code:'BB',name:'Barbados',flag:'🇧🇧'},{code:'BY',name:'Belarus',flag:'🇧🇾'},{code:'BE',name:'Belgium',flag:'🇧🇪'},{code:'BZ',name:'Belize',flag:'🇧🇿'},{code:'BJ',name:'Benin',flag:'🇧🇯'},{code:'BT',name:'Bhutan',flag:'🇧🇹'},{code:'BO',name:'Bolivia',flag:'🇧🇴'},{code:'BA',name:'Bosnia and Herzegovina',flag:'🇧🇦'},{code:'BW',name:'Botswana',flag:'🇧🇼'},{code:'BR',name:'Brazil',flag:'🇧🇷'},{code:'BN',name:'Brunei',flag:'🇧🇳'},{code:'BG',name:'Bulgaria',flag:'🇧🇬'},{code:'BF',name:'Burkina Faso',flag:'🇧🇫'},{code:'BI',name:'Burundi',flag:'🇧🇮'},{code:'CV',name:'Cabo Verde',flag:'🇨🇻'},{code:'KH',name:'Cambodia',flag:'🇰🇭'},{code:'CM',name:'Cameroon',flag:'🇨🇲'},{code:'CA',name:'Canada',flag:'🇨🇦'},{code:'CF',name:'Central African Republic',flag:'🇨🇫'},{code:'TD',name:'Chad',flag:'🇹🇩'},{code:'CL',name:'Chile',flag:'🇨🇱'},{code:'CN',name:'China',flag:'🇨🇳'},{code:'CO',name:'Colombia',flag:'🇨🇴'},{code:'KM',name:'Comoros',flag:'🇰🇲'},{code:'CG',name:'Congo',flag:'🇨🇬'},{code:'CD',name:'Congo (DRC)',flag:'🇨🇩'},{code:'CR',name:'Costa Rica',flag:'🇨🇷'},{code:'CI',name:"Côte d'Ivoire",flag:'🇨🇮'},{code:'HR',name:'Croatia',flag:'🇭🇷'},{code:'CU',name:'Cuba',flag:'🇨🇺'},{code:'CY',name:'Cyprus',flag:'🇨🇾'},{code:'CZ',name:'Czechia',flag:'🇨🇿'},{code:'DK',name:'Denmark',flag:'🇩🇰'},{code:'DJ',name:'Djibouti',flag:'🇩🇯'},{code:'DM',name:'Dominica',flag:'🇩🇲'},{code:'DO',name:'Dominican Republic',flag:'🇩🇴'},{code:'EC',name:'Ecuador',flag:'🇪🇨'},{code:'EG',name:'Egypt',flag:'🇪🇬'},{code:'SV',name:'El Salvador',flag:'🇸🇻'},{code:'GQ',name:'Equatorial Guinea',flag:'🇬🇶'},{code:'ER',name:'Eritrea',flag:'🇪🇷'},{code:'EE',name:'Estonia',flag:'🇪🇪'},{code:'SZ',name:'Eswatini',flag:'🇸🇿'},{code:'ET',name:'Ethiopia',flag:'🇪🇹'},{code:'FJ',name:'Fiji',flag:'🇫🇯'},{code:'FI',name:'Finland',flag:'🇫🇮'},{code:'FR',name:'France',flag:'🇫🇷'},{code:'GA',name:'Gabon',flag:'🇬🇦'},{code:'GM',name:'Gambia',flag:'🇬🇲'},{code:'GE',name:'Georgia',flag:'🇬🇪'},{code:'DE',name:'Germany',flag:'🇩🇪'},{code:'GH',name:'Ghana',flag:'🇬🇭'},{code:'GR',name:'Greece',flag:'🇬🇷'},{code:'GD',name:'Grenada',flag:'🇬🇩'},{code:'GT',name:'Guatemala',flag:'🇬🇹'},{code:'GN',name:'Guinea',flag:'🇬🇳'},{code:'GW',name:'Guinea-Bissau',flag:'🇬🇼'},{code:'GY',name:'Guyana',flag:'🇬🇾'},{code:'HT',name:'Haiti',flag:'🇭🇹'},{code:'HN',name:'Honduras',flag:'🇭🇳'},{code:'HU',name:'Hungary',flag:'🇭🇺'},{code:'IS',name:'Iceland',flag:'🇮🇸'},{code:'IN',name:'India',flag:'🇮🇳'},{code:'ID',name:'Indonesia',flag:'🇮🇩'},{code:'IR',name:'Iran',flag:'🇮🇷'},{code:'IQ',name:'Iraq',flag:'🇮🇶'},{code:'IE',name:'Ireland',flag:'🇮🇪'},{code:'IL',name:'Israel',flag:'🇮🇱'},{code:'IT',name:'Italy',flag:'🇮🇹'},{code:'JM',name:'Jamaica',flag:'🇯🇲'},{code:'JP',name:'Japan',flag:'🇯🇵'},{code:'JO',name:'Jordan',flag:'🇯🇴'},{code:'KZ',name:'Kazakhstan',flag:'🇰🇿'},{code:'KE',name:'Kenya',flag:'🇰🇪'},{code:'KI',name:'Kiribati',flag:'🇰🇮'},{code:'KW',name:'Kuwait',flag:'🇰🇼'},{code:'KG',name:'Kyrgyzstan',flag:'🇰🇬'},{code:'LA',name:'Laos',flag:'🇱🇦'},{code:'LV',name:'Latvia',flag:'🇱🇻'},{code:'LB',name:'Lebanon',flag:'🇱🇧'},{code:'LS',name:'Lesotho',flag:'🇱🇸'},{code:'LR',name:'Liberia',flag:'🇱🇷'},{code:'LY',name:'Libya',flag:'🇱🇾'},{code:'LI',name:'Liechtenstein',flag:'🇱🇮'},{code:'LT',name:'Lithuania',flag:'🇱🇹'},{code:'LU',name:'Luxembourg',flag:'🇱🇺'},{code:'MG',name:'Madagascar',flag:'🇲🇬'},{code:'MW',name:'Malawi',flag:'🇲🇼'},{code:'MY',name:'Malaysia',flag:'🇲🇾'},{code:'MV',name:'Maldives',flag:'🇲🇻'},{code:'ML',name:'Mali',flag:'🇲🇱'},{code:'MT',name:'Malta',flag:'🇲🇹'},{code:'MH',name:'Marshall Islands',flag:'🇲🇭'},{code:'MR',name:'Mauritania',flag:'🇲🇷'},{code:'MU',name:'Mauritius',flag:'🇲🇺'},{code:'MX',name:'Mexico',flag:'🇲🇽'},{code:'FM',name:'Micronesia',flag:'🇫🇲'},{code:'MD',name:'Moldova',flag:'🇲🇩'},{code:'MC',name:'Monaco',flag:'🇲🇨'},{code:'MN',name:'Mongolia',flag:'🇲🇳'},{code:'ME',name:'Montenegro',flag:'🇲🇪'},{code:'MA',name:'Morocco',flag:'🇲🇦'},{code:'MZ',name:'Mozambique',flag:'🇲🇿'},{code:'MM',name:'Myanmar',flag:'🇲🇲'},{code:'NA',name:'Namibia',flag:'🇳🇦'},{code:'NR',name:'Nauru',flag:'🇳🇷'},{code:'NP',name:'Nepal',flag:'🇳🇵'},{code:'NL',name:'Netherlands',flag:'🇳🇱'},{code:'NZ',name:'New Zealand',flag:'🇳🇿'},{code:'NI',name:'Nicaragua',flag:'🇳🇮'},{code:'NE',name:'Niger',flag:'🇳🇪'},{code:'NG',name:'Nigeria',flag:'🇳🇬'},{code:'KP',name:'North Korea',flag:'🇰🇵'},{code:'MK',name:'North Macedonia',flag:'🇲🇰'},{code:'NO',name:'Norway',flag:'🇳🇴'},{code:'OM',name:'Oman',flag:'🇴🇲'},{code:'PK',name:'Pakistan',flag:'🇵🇰'},{code:'PW',name:'Palau',flag:'🇵🇼'},{code:'PS',name:'Palestine',flag:'🇵🇸'},{code:'PA',name:'Panama',flag:'🇵🇦'},{code:'PG',name:'Papua New Guinea',flag:'🇵🇬'},{code:'PY',name:'Paraguay',flag:'🇵🇾'},{code:'PE',name:'Peru',flag:'🇵🇪'},{code:'PH',name:'Philippines',flag:'🇵🇭'},{code:'PL',name:'Poland',flag:'🇵🇱'},{code:'PT',name:'Portugal',flag:'🇵🇹'},{code:'QA',name:'Qatar',flag:'🇶🇦'},{code:'RO',name:'Romania',flag:'🇷🇴'},{code:'RU',name:'Russia',flag:'🇷🇺'},{code:'RW',name:'Rwanda',flag:'🇷🇼'},{code:'KN',name:'Saint Kitts and Nevis',flag:'🇰🇳'},{code:'LC',name:'Saint Lucia',flag:'🇱🇨'},{code:'VC',name:'Saint Vincent and the Grenadines',flag:'🇻🇨'},{code:'WS',name:'Samoa',flag:'🇼🇸'},{code:'SM',name:'San Marino',flag:'🇸🇲'},{code:'ST',name:'São Tomé and Príncipe',flag:'🇸🇹'},{code:'SA',name:'Saudi Arabia',flag:'🇸🇦'},{code:'SN',name:'Senegal',flag:'🇸🇳'},{code:'RS',name:'Serbia',flag:'🇷🇸'},{code:'SC',name:'Seychelles',flag:'🇸🇨'},{code:'SL',name:'Sierra Leone',flag:'🇸🇱'},{code:'SG',name:'Singapore',flag:'🇸🇬'},{code:'SK',name:'Slovakia',flag:'🇸🇰'},{code:'SI',name:'Slovenia',flag:'🇸🇮'},{code:'SB',name:'Solomon Islands',flag:'🇸🇧'},{code:'SO',name:'Somalia',flag:'🇸🇴'},{code:'ZA',name:'South Africa',flag:'🇿🇦'},{code:'KR',name:'South Korea',flag:'🇰🇷'},{code:'SS',name:'South Sudan',flag:'🇸🇸'},{code:'ES',name:'Spain',flag:'🇪🇸'},{code:'LK',name:'Sri Lanka',flag:'🇱🇰'},{code:'SD',name:'Sudan',flag:'🇸🇩'},{code:'SR',name:'Suriname',flag:'🇸🇷'},{code:'SE',name:'Sweden',flag:'🇸🇪'},{code:'CH',name:'Switzerland',flag:'🇨🇭'},{code:'SY',name:'Syria',flag:'🇸🇾'},{code:'TW',name:'Taiwan',flag:'🇹🇼'},{code:'TJ',name:'Tajikistan',flag:'🇹🇯'},{code:'TZ',name:'Tanzania',flag:'🇹🇿'},{code:'TH',name:'Thailand',flag:'🇹🇭'},{code:'TL',name:'Timor-Leste',flag:'🇹🇱'},{code:'TG',name:'Togo',flag:'🇹🇬'},{code:'TO',name:'Tonga',flag:'🇹🇴'},{code:'TT',name:'Trinidad and Tobago',flag:'🇹🇹'},{code:'TN',name:'Tunisia',flag:'🇹🇳'},{code:'TR',name:'Turkey',flag:'🇹🇷'},{code:'TM',name:'Turkmenistan',flag:'🇹🇲'},{code:'TV',name:'Tuvalu',flag:'🇹🇻'},{code:'UG',name:'Uganda',flag:'🇺🇬'},{code:'UA',name:'Ukraine',flag:'🇺🇦'},{code:'AE',name:'United Arab Emirates',flag:'🇦🇪'},{code:'GB',name:'United Kingdom',flag:'🇬🇧'},{code:'US',name:'United States',flag:'🇺🇸'},{code:'UY',name:'Uruguay',flag:'🇺🇾'},{code:'UZ',name:'Uzbekistan',flag:'🇺🇿'},{code:'VU',name:'Vanuatu',flag:'🇻🇺'},{code:'VA',name:'Vatican City',flag:'🇻🇦'},{code:'VE',name:'Venezuela',flag:'🇻🇪'},{code:'VN',name:'Vietnam',flag:'🇻🇳'},{code:'YE',name:'Yemen',flag:'🇾🇪'},{code:'ZM',name:'Zambia',flag:'🇿🇲'},{code:'ZW',name:'Zimbabwe',flag:'🇿🇼'}];
 const COUNTRY_NAMES=Object.fromEntries(COUNTRIES.map(c=>[c.code,c.name]));
const COUNTRY_FLAGS=Object.fromEntries(COUNTRIES.map(c=>[c.code,c.flag]));
const COUNTRY_CUR_MAP=(()=>{const m={};COUNTRIES.forEach(c=>{const match=CURRENCIES.find(cur=>cur.flag===c.flag);if(match)m[c.code]=match.code;});return m;})();
function __defaultCurrencyForCountry(){try{const cc=window.__profileData&&window.__profileData.country;const curCode=cc&&COUNTRY_CUR_MAP[cc];return curCode?(CURRENCIES.find(c=>c.code===curCode)||null):null;}catch(e){return null;}}
const CATEGORY_DATA=[
  {group:"Fashion & Style",items:["Activewear","Bags","Clothing","Intimates","Jewelry","Shoes","Sunglasses","Watches"]},
  {group:"Health & Beauty",items:["Beauty","Fragrance","Grooming","Haircare","Makeup","Skincare","Supplements","Wellness"]},
  {group:"Home & Living",items:["Appliances","Bath","Bedding","Decor","Furniture","Garden","Home","Kitchen","Lighting"]},
  {group:"Kids & Play",items:["Baby","Crafts","Hobbies","Kids","Maternity","Toys"]},
  {group:"Sports & Outdoors",items:["Camping","Cycling","Fishing","Fitness","Outdoors","Sports"]},
  {group:"Tech & Electronics",items:["Accessories","Audio","Cameras","Computers","Electronics","Gaming","Phones","Tablets","Wearables"]},
  {group:"Utility & Niche",items:["Automotive","Books","Groceries","Office","Pets","Stationery","Tools"]}
];
const CATEGORY_GROUP_AR={"Fashion & Style":"الأزياء والموضة","Health & Beauty":"الصحة والجمال","Home & Living":"المنزل والمعيشة","Kids & Play":"الأطفال واللعب","Sports & Outdoors":"الرياضة والأنشطة الخارجية","Tech & Electronics":"التقنية والإلكترونيات","Utility & Niche":"المستلزمات العامة والمتنوعة"};
const CATEGORY_ITEM_AR={"Activewear":"الملابس الرياضية","Bags":"الحقائب","Clothing":"الملابس","Intimates":"الملابس الداخلية","Jewelry":"المجوهرات","Shoes":"الأحذية","Sunglasses":"النظارات الشمسية","Watches":"الساعات","Beauty":"منتجات التجميل","Fragrance":"العطور","Grooming":"العناية الشخصية","Haircare":"العناية بالشعر","Makeup":"المكياج","Skincare":"العناية بالبشرة","Supplements":"المكملات الغذائية","Wellness":"الصحة والعافية","Appliances":"الأجهزة المنزلية","Bath":"مستلزمات الحمام","Bedding":"مستلزمات النوم","Decor":"الديكور","Furniture":"الأثاث","Garden":"مستلزمات الحديقة","Home":"مستلزمات المنزل","Kitchen":"مستلزمات المطبخ","Lighting":"الإضاءة","Baby":"مستلزمات الأطفال الرضع","Crafts":"الأشغال اليدوية","Hobbies":"الهوايات","Kids":"مستلزمات الأطفال","Maternity":"مستلزمات الأمومة","Toys":"الألعاب","Camping":"التخييم","Cycling":"ركوب الدراجات","Fishing":"صيد الأسماك","Fitness":"اللياقة البدنية","Outdoors":"الأنشطة الخارجية","Sports":"الرياضة","Accessories":"الإكسسوارات","Audio":"الأجهزة الصوتية","Cameras":"الكاميرات","Computers":"أجهزة الكمبيوتر","Electronics":"الإلكترونيات","Gaming":"الألعاب الإلكترونية","Phones":"الهواتف","Tablets":"الأجهزة اللوحية","Wearables":"الأجهزة القابلة للارتداء","Automotive":"مستلزمات السيارات","Books":"الكتب","Groceries":"البقالة","Office":"المستلزمات المكتبية","Pets":"مستلزمات الحيوانات الأليفة","Stationery":"القرطاسية","Tools":"الأدوات"};
function mpCategoryLabel(cat){if(!cat)return'';let key=cat;if(!CATEGORY_ITEM_AR[key]){const found=Object.keys(CATEGORY_ITEM_AR).find(k=>CATEGORY_ITEM_AR[k]===cat);if(found)key=found;}return __ar()?(CATEGORY_ITEM_AR[key]||key):key;}
let selectedCategory='';
let categoryPanelOpen=false;
function renderCategoryList(filter){
  const listEl=document.getElementById('category-list');if(!listEl)return;
  const q=(filter||'').trim().toLowerCase();
  const ar=__ar();
  let html='';let any=false;
  CATEGORY_DATA.forEach(section=>{
    const groupLbl=ar?(CATEGORY_GROUP_AR[section.group]||section.group):section.group;
    const groupMatches=section.group.toLowerCase().includes(q)||groupLbl.toLowerCase().includes(q);
    const items=section.items.filter(it=>groupMatches||it.toLowerCase().includes(q)||(ar&&(CATEGORY_ITEM_AR[it]||'').includes(filter||'')));
    if(!items.length)return;
    any=true;
    html+=`<div class="lp-category-group-label" data-no-i18n>${groupLbl}</div>`;
    items.forEach(it=>{const lbl=ar?(CATEGORY_ITEM_AR[it]||it):it;html+=`<div class="lp-category-option" data-no-i18n onclick="selectCategory('${it.replace(/'/g,"\\'")}')">${lbl}</div>`;});
  });
  if(!any)html=`<div class="lp-category-empty" data-no-i18n>${ar?'لا توجد فئات مطابقة':'No matching categories'}</div>`;
  listEl.innerHTML=html;
}
function openCategoryPanel(){document.getElementById('category-panel').classList.add('open');document.getElementById('category-picker-input').classList.add('open');const s=document.getElementById('category-search');if(s){s.value='';setTimeout(()=>s.focus(),0);}renderCategoryList('');categoryPanelOpen=true;}
function closeCategoryPanel(){document.getElementById('category-panel').classList.remove('open');document.getElementById('category-picker-input').classList.remove('open');categoryPanelOpen=false;}
function toggleCategoryPanel(){if(categoryPanelOpen)closeCategoryPanel();else openCategoryPanel();}
function selectCategory(name){selectedCategory=name;const v=document.getElementById('category-picker-value');v.textContent=__ar()?(CATEGORY_ITEM_AR[name]||name):name;v.setAttribute('data-no-i18n','');v.classList.remove('placeholder');closeCategoryPanel();}
document.addEventListener('click',(e)=>{const picker=document.getElementById('category-picker');if(picker&&categoryPanelOpen&&!picker.contains(e.target))closeCategoryPanel();});
 const BUSINESS={name:'Sunrise Kicks Ltd.',phone:'+44 20 1234 5678'};
 let photos=[],variantGroups=[],zones={},editingId=null,commMode='pct',currentCode='',variantIdCounter=0,groupIdCounter=0,selectedCurrency=null,currDropdownOpen=false,countryDropdownOpen=false,selectedCountry=null,__photoUploadJobs=[],__variantPhotoUploadJobs=[],variantMode='none',simpleQty='';
const genCode=(len)=>{const c='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';const n=len||6;let s='LT-';for(let i=0;i<n;i++)s+=c[Math.floor(Math.random()*c.length)];return s;};
const genId=()=>'p'+Math.random().toString(36).substr(2,5);
const pctOf=(price,pct)=>parseFloat((price*(pct/100)).toFixed(2));
let products=[];

/* ── Backend bridge: map DB rows to the in-memory shape this UI expects ── */
function dbToProduct(r){const cur=r.currency?{...r.currency,symbol:__wrapArSym(r.currency.symbol,r.currency.code)}:null;return{id:r.id,code:r.code,bizName:r.biz_name||'',currency:cur,photos:r.photos||[],name:r.name,desc:r.description||'',price:Number(r.price)||0,costPrice:Number(r.cost_price)||0,commPct:Number(r.comm_pct)||0,commFixed:Number(r.comm_fixed)||0,commMode:r.comm_mode||'pct',platformFee:Number(r.platform_fee)||0,totalFeePerUnit:Number(r.total_fee_per_unit)||0,qty:Number(r.qty)||0,category:r.category||'',sizes:r.sizes||[],colors:r.colors||[],variantGroups:r.variant_groups||[],sold:Number(r.sold)||0,revenue:Number(r.revenue)||0,status:r.status||'active',delivery:r.delivery||{}};}
async function loadProducts(){if(!window.LateenAPI)return;try{const rows=await window.LateenAPI.listMyProducts();products=rows.map(dbToProduct);renderProducts();}catch(e){console.error('[Lateen] loadProducts',e);}}
let __unsubProducts=null;
function __soonBadge(){return '<span class="soon-badge">' + (__ar() ? 'قريباً' : 'soon') + '</span>';}
function filterCurrencies(){renderCurrencyDropdown([]);}
function renderCurrencyDropdown(list){
  const ar=__ar();
  const lyd=CURRENCIES.find(c=>c.code==='LYD');
  const eur=CURRENCIES.find(c=>c.code==='EUR');
  const usd=CURRENCIES.find(c=>c.code==='USD');
  const sb=__soonBadge();
  const moreLabel=ar?'عملات أخرى':'More currencies';
  let html='';
  if(lyd) html+=`<div class="currency-option" onclick="selectCurrency('LYD')"><span class="curr-flag">${lyd.flag}</span><span class="curr-label">${lyd.name}</span><span class="curr-sub">${lyd.code} · ${lyd.symbol}</span></div>`;
  if(eur) html+=`<div class="currency-option disabled" onclick="event.stopPropagation();"><span class="curr-flag">${eur.flag}</span><span class="curr-label">${eur.name}</span><span class="curr-sub">${eur.code} · ${eur.symbol}</span><span style="margin-left:auto">${sb}</span></div>`;
  if(usd) html+=`<div class="currency-option disabled" onclick="event.stopPropagation();"><span class="curr-flag">${usd.flag}</span><span class="curr-label">${usd.name}</span><span class="curr-sub">${usd.code} · ${usd.symbol}</span><span style="margin-left:auto">${sb}</span></div>`;
  html+=`<div class="currency-option disabled" onclick="event.stopPropagation();"><span class="curr-label" style="color:var(--color-text-tertiary)">${moreLabel}</span><span style="margin-left:auto">${sb}</span></div>`;
  document.getElementById('curr-dropdown').innerHTML=html;
}
function toggleCurrencyDropdown(){currDropdownOpen=!currDropdownOpen;document.getElementById('curr-dropdown').classList.toggle('open',currDropdownOpen);document.getElementById('curr-search-wrap').style.display=currDropdownOpen?'block':'none';if(currDropdownOpen){renderCurrencyDropdown(CURRENCIES);setTimeout(()=>document.getElementById('curr-search').focus(),50);}}
function selectCurrency(code){selectedCurrency=CURRENCIES.find(c=>c.code===code);document.getElementById('curr-flag').textContent=selectedCurrency.flag;document.getElementById('curr-name').textContent=selectedCurrency.name+' ('+selectedCurrency.code+')';document.getElementById('curr-symbol-label').textContent=selectedCurrency.symbol;document.getElementById('price-prefix').textContent=selectedCurrency.symbol;updateCommFixedUnitLabel();currDropdownOpen=false;document.getElementById('curr-dropdown').classList.remove('open');document.getElementById('curr-search-wrap').style.display='none';document.getElementById('curr-search').value='';updateFeeBreakdown();}
function calcFees(price,pct,fixedComm,mode){const comm=mode==='pct'?pctOf(price,pct):parseFloat(fixedComm||0);const platform=parseFloat((price*PLATFORM_FEE_RATE).toFixed(2));const total=parseFloat((comm+platform).toFixed(2));const commPct=mode==='pct'?pct:parseFloat(((comm/price)*100).toFixed(1));return{comm,platform,total,commPct};}
function updateConversionNote(){const note=document.getElementById('conversion-note');if(!note)return;const price=parseFloat(document.getElementById('f-price').value)||0;const code=selectedCurrency?selectedCurrency.code:'LYD';const ar=__ar();if(commMode==='pct'){const pct=parseFloat(document.getElementById('f-comm-pct').value)||0;const amt=pctOf(price,pct);note.innerHTML=ar?`مبلغ ربح المسوق: <b>${__moneyH(amt,'د.ل','LYD')}</b> لكل قطعه`:`Fixed equivalent at current price: <b>${amt.toFixed(2)} ${code}</b> per sale`;}else{const fixed=parseFloat(document.getElementById('f-comm-fixed').value)||0;const pct=price?((fixed/price)*100):0;note.innerHTML=ar?`نسبه ربح المسوق : <b>${pct.toFixed(1)}%</b> لكل قطعه`:`Percentage equivalent at current price: <b>${pct.toFixed(1)}%</b> per sale`;}}
function updateProductSummaryCard(){const price=parseFloat(document.getElementById('f-price').value)||0;const pct=parseFloat(document.getElementById('f-comm-pct').value)||0;const fixed=parseFloat(document.getElementById('f-comm-fixed').value)||0;const code=selectedCurrency?selectedCurrency.code:'LYD';const codeLbl=(__ar()&&code==='LYD')?'د.ل':code;const fmtSum=(n)=>(__ar()&&code==='LYD')?__moneyH(n,'د.ل','LYD'):`${n.toFixed(2)} <span class="cur-sym">${codeLbl}</span>`;const{comm,platform,commPct}=calcFees(price,pct,fixed,commMode);const total=price-comm-platform;const set=(id,v)=>{const el=document.getElementById(id);if(el)el.innerHTML=v;};set('sum-price',fmtSum(price));set('sum-marketer-label',__ar()?`عمولة المسوق (${commPct}%)`:`Marketer commission (${commPct}%)`);set('sum-marketer-amt',fmtSum(comm));set('sum-platform-amt',fmtSum(platform));set('sum-total',fmtSum(total));}
function updateFeeBreakdown(){updateConversionNote();updateProductSummaryCard();}
function onPriceChange(){const price=parseFloat(document.getElementById('f-price').value)||0;if(commMode==='pct'){const pct=parseFloat(document.getElementById('f-comm-pct').value)||0;if(pct)document.getElementById('f-comm-fixed').value=pctOf(price,pct);}else{const fixed=parseFloat(document.getElementById('f-comm-fixed').value)||0;if(price&&fixed)document.getElementById('f-comm-pct').value=((fixed/price)*100).toFixed(1);}updateFeeBreakdown();}
function onCommPctChange(){const price=parseFloat(document.getElementById('f-price').value)||0;const pct=parseFloat(document.getElementById('f-comm-pct').value)||0;if(price&&pct)document.getElementById('f-comm-fixed').value=pctOf(price,pct);updateFeeBreakdown();}
function onCommFixedChange(){const price=parseFloat(document.getElementById('f-price').value)||0;const fixed=parseFloat(document.getElementById('f-comm-fixed').value)||0;if(price&&fixed)document.getElementById('f-comm-pct').value=((fixed/price)*100).toFixed(1);updateFeeBreakdown();}
function updateCommFixedUnitLabel(){const el=document.getElementById('comm-fixed-unit');if(!el)return;const code=selectedCurrency?selectedCurrency.code:'LYD';el.textContent=`${code} per sale`;}
function setCommMode(mode){commMode=mode;document.getElementById('mode-pct').classList.toggle('active',mode==='pct');document.getElementById('mode-fixed').classList.toggle('active',mode==='fixed');document.getElementById('row-comm-pct').style.display=mode==='pct'?'flex':'none';document.getElementById('row-comm-fixed').style.display=mode==='fixed'?'flex':'none';updateCommFixedUnitLabel();updateFeeBreakdown();}
function __isBlobUrl(u){return typeof u==='string'&&u.startsWith('blob:');}
async function __waitForProductPhotoUploads(){const jobs=[...__photoUploadJobs,...__variantPhotoUploadJobs].filter(Boolean);if(jobs.length)await Promise.allSettled(jobs);}
function onPhotosSelected(input){const files=Array.from(input.files);input.value='';const slots=[];for(const file of files){if(photos.length>=6)break;const localUrl=URL.createObjectURL(file);photos.push(localUrl);slots.push({file,localUrl});}renderPhotoGrid();const job=(async()=>{await Promise.all(slots.map(async s=>{try{if(window.LateenAPI&&window.LateenAPI.uploadPhoto){const url=await window.LateenAPI.uploadPhoto(s.file);const curIdx=photos.indexOf(s.localUrl);if(curIdx!==-1)photos[curIdx]=url;}else{const url=await new Promise((res,rej)=>{const r=new FileReader();r.onload=e=>res(e.target.result);r.onerror=rej;r.readAsDataURL(s.file);});const curIdx=photos.indexOf(s.localUrl);if(curIdx!==-1)photos[curIdx]=url;}try{URL.revokeObjectURL(s.localUrl);}catch(e){}}catch(e){console.error('[Lateen] uploadPhoto',e);const curIdx=photos.indexOf(s.localUrl);if(curIdx!==-1)photos.splice(curIdx,1);alert('Photo upload failed.');}}));renderPhotoGrid();})();__photoUploadJobs.push(job);job.finally(()=>{__photoUploadJobs=__photoUploadJobs.filter(j=>j!==job);});}
function removePhoto(i){photos.splice(i,1);renderPhotoGrid();}
function renderPhotoGrid(){const g=document.getElementById('photo-grid');if(!g)return;g.innerHTML=photos.map((src,i)=>`<div class="photo-preview"><img src="${src}"/><button class="photo-remove" onclick="removePhoto(${i})">×</button></div>`).join('')+(photos.length<6?`<div class="add-photo-btn" onclick="document.getElementById('photo-input').click()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--color-text-secondary)" stroke-width="1.6" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><div class="add-photo-label">Add photo</div></div>`:'');}
function addVariantGroup(){variantGroups.push({id:groupIdCounter++,name:'',placeholder:__ar()?'مثال: المقاس او اللون':'Example: color or size',valPlaceholder:__ar()?'مثال: أسود أو XL':'Black or XL',items:[]});renderVariantGroups();setTimeout(()=>{const ins=document.querySelectorAll('.vg-name-input');if(ins.length)ins[ins.length-1].focus();},50);}
function setVariantMode(mode){variantMode=mode==='variants'?'variants':'none';const noneBtn=document.getElementById('variant-mode-none-btn');const groupsBtn=document.getElementById('variant-mode-groups-btn');if(noneBtn)noneBtn.classList.toggle('active',variantMode==='none');if(groupsBtn)groupsBtn.classList.toggle('active',variantMode==='variants');const simpleSec=document.getElementById('simple-qty-section');const groupsSec=document.getElementById('variant-groups-section');if(simpleSec)simpleSec.style.display=variantMode==='none'?'block':'none';if(groupsSec)groupsSec.style.display=variantMode==='variants'?'block':'none';if(variantMode==='variants'&&!variantGroups.length){variantGroups.push({id:groupIdCounter++,name:'',placeholder:__ar()?'مثال: المقاس او اللون':'Example: color or size',valPlaceholder:__ar()?'مثال: أسود أو XL':'Black or XL',items:[{id:variantIdCounter++,val:'',qty:'',photo:''}]});renderVariantGroups();}}
function updateSimpleQty(val){simpleQty=val;}
function __stepSimpleQty(d){const el=document.getElementById('f-simple-qty');if(!el)return;const cur=Math.max(0,parseInt(el.value||'0',10)||0);const nv=Math.max(0,cur+d);el.value=String(nv);simpleQty=String(nv);}
function __onSimpleQtyInput(el){let v=parseInt(el.value||'',10);if(!Number.isFinite(v)||v<0)v=0;el.value=String(v);simpleQty=String(v);}
function __stepVariantQty(gid,iid,d){const g=variantGroups.find(x=>x.id===gid);if(!g)return;const it=g.items.find(x=>x.id===iid);if(!it)return;const cur=Math.max(1,parseInt(String(it.qty||'1'),10)||1);const nv=Math.max(1,cur+d);it.qty=nv;const inp=document.getElementById('vb-qty-'+gid+'-'+iid);if(inp)inp.value=String(nv);updateVariantTotalStock();}
function __onVariantQtyInput(gid,iid,el){let v=parseInt(el.value||'',10);if(!Number.isFinite(v)||v<1)v=1;el.value=String(v);updateVariantQty(gid,iid,String(v));}
if(typeof window!=='undefined'){window.__stepSimpleQty=__stepSimpleQty;window.__onSimpleQtyInput=__onSimpleQtyInput;window.__stepVariantQty=__stepVariantQty;window.__onVariantQtyInput=__onVariantQtyInput;}
function updateVariantTotalStock(){const bar=document.getElementById('variant-total-stock-bar');const val=document.getElementById('variant-total-stock-val');const lbl=document.getElementById('variant-total-stock-label');if(!bar||!val)return;if(lbl)lbl.textContent=__ar()?'إجمالي الكميه':'Total stock';const hasAny=variantGroups.some(g=>(g.items||[]).length);bar.style.display=hasAny?'flex':'none';if(!hasAny)return;const total=variantGroups.reduce((s,g)=>s+(g.items||[]).reduce((s2,x)=>s2+(Number(x.qty)||0),0),0);val.textContent=total.toLocaleString();}
function removeVariantGroup(gid){variantGroups=variantGroups.filter(g=>g.id!==gid);renderVariantGroups();}
function renameVariantGroup(gid,name){const g=variantGroups.find(x=>x.id===gid);if(g)g.name=name;}
function addVariant(gid){const g=variantGroups.find(x=>x.id===gid);if(!g)return;g.items.push({id:variantIdCounter++,val:'',qty:1,photo:''});renderVariantGroups();setTimeout(()=>{const ins=document.querySelectorAll(`#vg-list-${gid} input.vb-val-input`);if(ins.length)ins[ins.length-1].focus();},50);}
function removeVariant(gid,id){const g=variantGroups.find(x=>x.id===gid);if(g){g.items=g.items.filter(x=>x.id!==id);renderVariantGroups();}}
function updateVariant(gid,id,val){const g=variantGroups.find(x=>x.id===gid);if(!g)return;const it=g.items.find(x=>x.id===id);if(it)it.val=val;}
function updateVariantQty(gid,id,val){const g=variantGroups.find(x=>x.id===gid);if(!g)return;const it=g.items.find(x=>x.id===id);if(it)it.qty=val;updateVariantTotalStock();}
function onVariantPhotoSelected(gid,id,input){const file=input.files&&input.files[0];input.value='';if(!file)return;const g=variantGroups.find(x=>x.id===gid);if(!g)return;const it=g.items.find(x=>x.id===id);if(!it)return;const localUrl=URL.createObjectURL(file);it.photo=localUrl;renderVariantGroups();const job=(async()=>{try{let url;if(window.LateenAPI&&window.LateenAPI.uploadPhoto){url=await window.LateenAPI.uploadPhoto(file);}else{url=await new Promise((res,rej)=>{const r=new FileReader();r.onload=e=>res(e.target.result);r.onerror=rej;r.readAsDataURL(file);});}const g2=variantGroups.find(x=>x.id===gid);if(!g2)return;const it2=g2.items.find(x=>x.id===id);if(!it2)return;it2.photo=url;try{URL.revokeObjectURL(localUrl);}catch(e){}renderVariantGroups();}catch(e){console.error('[Lateen] variant photo upload',e);const g2=variantGroups.find(x=>x.id===gid);const it2=g2&&g2.items.find(x=>x.id===id);if(it2){it2.photo='';renderVariantGroups();}alert('Photo upload failed.');}})();__variantPhotoUploadJobs.push(job);job.finally(()=>{__variantPhotoUploadJobs=__variantPhotoUploadJobs.filter(j=>j!==job);});}
function removeVariantPhoto(gid,id){const g=variantGroups.find(x=>x.id===gid);if(!g)return;const it=g.items.find(x=>x.id===id);if(!it)return;it.photo='';renderVariantGroups();}
function renderVariantGroups(){const el=document.getElementById('variant-groups-container');if(!el)return;if(!variantGroups.length){el.innerHTML='<div class="vb-empty" style="border:0.5px dashed var(--color-border-secondary);border-radius:12px;margin-bottom:12px">No variants. Tap "Add another variant" below.</div>';updateVariantTotalStock();return;}const ar=__ar();const addPhLbl=ar?'صورة':'Photo';el.innerHTML=variantGroups.map(g=>{const ph=g.placeholder||(ar?'مثال: المقاس او اللون':'Example: color or size');const valPh=g.valPlaceholder||(ar?'مثال: أسود أو XL':'Black or XL');return`<div class="variant-builder"><div class="vb-header"><input class="vg-name-input" type="text" value="${(g.name||'').replace(/"/g,'&quot;')}" oninput="renameVariantGroup(${g.id},this.value)" placeholder="${ph}"/><button class="vg-remove-btn" onclick="removeVariantGroup(${g.id})" title="Remove group">×</button></div><div id="vg-list-${g.id}">${g.items.length?g.items.map(it=>{const thumb=it.photo?`<div class="vb-thumb"><img src="${it.photo}"/><button class="vb-thumb-x" onclick="removeVariantPhoto(${g.id},${it.id})">×</button></div>`:`<label class="vb-thumb vb-thumb-add" title="${addPhLbl}"><input type="file" accept="image/*" style="display:none" onchange="onVariantPhotoSelected(${g.id},${it.id},this)"/><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--color-text-secondary)" stroke-width="1.8" stroke-linecap="round"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg></label>`;const qVal=(it.qty===''||it.qty==null||isNaN(Number(it.qty))||Number(it.qty)<1)?1:Number(it.qty);return`<div class="vb-item"><input class="vb-val-input" type="text" value="${(it.val||'').replace(/"/g,'&quot;')}" placeholder="${valPh}" oninput="updateVariant(${g.id},${it.id},this.value)" onkeydown="if(event.key==='Enter'){event.preventDefault();addVariant(${g.id});}"/><button class="vb-remove" onclick="removeVariant(${g.id},${it.id})">×</button><div class="vb-stepper"><button type="button" class="vb-stepper-btn" onclick="__stepVariantQty(${g.id},${it.id},-1)" aria-label="decrease">−</button><input class="vb-stepper-val" id="vb-qty-${g.id}-${it.id}" type="number" min="1" step="1" inputmode="numeric" value="${qVal}" oninput="__onVariantQtyInput(${g.id},${it.id},this)"/><button type="button" class="vb-stepper-btn" onclick="__stepVariantQty(${g.id},${it.id},1)" aria-label="increase">+</button></div>${thumb}</div>`;}).join(''):'<div class="vb-empty">Skip if not applicable</div>'}</div><div class="vb-add-btn" onclick="addVariant(${g.id})">+ Add value</div></div>`;}).join('');updateVariantTotalStock();}
function filterCountries(){renderCountryDropdown([]);}
function renderCountryDropdown(list){
  const ar=__ar();
  const ly=COUNTRIES.find(c=>c.code==='LY');
  const sb=__soonBadge();
  const moreLabel=ar?'دول أخرى':'More countries';
  let html='';
  if(ly) html+=`<div class="currency-option" onclick="selectCountry('LY')"><span class="curr-flag">${ly.flag}</span><span class="curr-label">${ly.name}</span><span class="curr-sub">${ly.code}</span></div>`;
  html+=`<div class="currency-option disabled" onclick="event.stopPropagation();"><span class="curr-label" style="color:var(--color-text-tertiary)">${moreLabel}</span><span style="margin-left:auto">${sb}</span></div>`;
  document.getElementById('country-dropdown').innerHTML=html;
}
function toggleCountryDropdown(){countryDropdownOpen=!countryDropdownOpen;document.getElementById('country-dropdown').classList.toggle('open',countryDropdownOpen);document.getElementById('country-search-wrap').style.display=countryDropdownOpen?'block':'none';if(countryDropdownOpen){renderCountryDropdown([]);setTimeout(()=>document.getElementById('country-search').focus(),50);}}
function selectCountry(code){if(!zones[code])zones[code]={cities:{},shipping:''};countryDropdownOpen=false;document.getElementById('country-dropdown').classList.remove('open');document.getElementById('country-search-wrap').style.display='none';const s=document.getElementById('country-search');if(s)s.value='';if(!selectedCurrency&&COUNTRY_CUR_MAP[code]){const match=CURRENCIES.find(c=>c.code===COUNTRY_CUR_MAP[code]);if(match)selectCurrency(match.code);}renderZoneBuilderList();}
function addZone(){/* kept for backward compatibility; selection now adds the zone directly via selectCountry */}
function removeZone(code){delete zones[code];renderZoneBuilderList();}
const LIBYA_CITIES=[{en:'Suluq',ar:'سلوق'},{en:'Ghemines',ar:'قمينس'},{en:'Ajdabiya',ar:'اجدابيا'},{en:'Al Kuwayfiyah',ar:'الكويفيه'},{en:'Ras Al Minqar',ar:'راس المنقار'},{en:'Sidi Khalifa',ar:'سي خليفه'},{en:'Al Abyar',ar:'لبيار'},{en:'Driana',ar:'دريانه'},{en:'Bersis',ar:'برسس'},{en:'Al Mabni',ar:'المبني'},{en:'Tocra',ar:'توكره'},{en:'Istatah',ar:'اسطاطه'},{en:'Al Aweilia',ar:'لعويله'},{en:'Murad Masud',ar:'مراد مسعود'},{en:'Al Aquriyah',ar:'العقوريه'},{en:'Zueitina',ar:'زويتنه'},{en:'Al Bakkur',ar:'البكور'},{en:'Al Wardiyah',ar:'الورديه'},{en:'Farzughah',ar:'فرزوغه'},{en:'Tacnis',ar:'تاكنس'},{en:'Battah',ar:'بطه'},{en:'Al Marj',ar:'المرج'},{en:'Jardas',ar:'جردس'},{en:'Zawiyat al Arqub',ar:'زاوية العرقوب'},{en:'Belhadid',ar:'بلحديد'},{en:'Qasr Libya',ar:'قصر ليبيا'},{en:'Wadi al Kuf',ar:'وادي الكوف'},{en:'Al Bayadah',ar:'البياضه'},{en:'Marawah',ar:'مراوه'},{en:'Massah',ar:'مسه'},{en:'Al Bayda',ar:'البيضاء'},{en:'Shahat',ar:'شحات'},{en:'Wardamah',ar:'وردامه'},{en:'Ras Turab',ar:'راس تراب'},{en:'Qarnadah',ar:'قرناده'},{en:'Omar Al Mukhtar',ar:'عمر المختار'},{en:'Qandulah',ar:'قندوله'},{en:'Al Haniyah',ar:'الحنيه'},{en:'Al Wasitah',ar:'الوسيطه'},{en:'Al Faidiyah',ar:'الفايديه'},{en:'Al Abraq',ar:'الابرق'},{en:'Susa',ar:'سوسه'},{en:'Al Mansurah',ar:'المنصوره'},{en:'Al Qubbah',ar:'القبه'},{en:'Belkhather',ar:'بالخاثر'},{en:'Qardabah',ar:'قرضبه'},{en:'Tobruk',ar:'طبرق'},{en:'Bab al Zaytun',ar:'باب الزيتون'},{en:"Al Qa'rah",ar:'القعره'},{en:'Kamboot',ar:'كمبوت'},{en:'Al Watar',ar:'الوتر'},{en:'Bir al Ashhab',ar:'بئر الاشهب'},{en:'Bardia',ar:'البردي'},{en:'Emsaed',ar:'امساعد'},{en:'Al Jaghbub',ar:'الجغبوب'},{en:'Ain Marah',ar:'عين ماره'},{en:'Derna',ar:'درنه'},{en:'Umm al Rizam',ar:'ام رزم'},{en:'Martuba',ar:'مرتوبه'},{en:'Gulf of Bomba',ar:'خليج البمبه'},{en:'Ras al Helal',ar:'راس الهلال'},{en:'Kersa',ar:'كرسه'},{en:'Al Mikhili',ar:'المخيلي'},{en:'Al Aziyat',ar:'العزيات'},{en:'Al Tamimi',ar:'التميمي'},{en:'Ain al Ghazalah',ar:'عين الغزاله'},{en:'Brega',ar:'البريقه'},{en:'Al Uqaylah',ar:'العقيله'},{en:'Ras Lanuf',ar:'راس لانوف'},{en:'Bin Jawad',ar:'بن جواد'},{en:'Harawa',ar:'اهراوه'},{en:'Sirte',ar:'سرت'},{en:'Tawergha',ar:'تورغاء'},{en:'Misrata',ar:'مصراته'},{en:'Zliten',ar:'زليتن'},{en:'Wadi Kaam',ar:'وادي كعام'},{en:'Al Khums',ar:'الخمس'},{en:'Qasr Al Khiyar',ar:'قصر الخيار'},{en:'Al Alous',ar:'العلوص'},{en:'Garabulli',ar:'القرابولي'},{en:'Tripoli',ar:'طرابلس'},{en:'Msallata',ar:'مسلاته'},{en:'Tarhuna',ar:'ترهونه'},{en:'Bishr',ar:'بشر'},{en:'The South',ar:'الجنوب'},{en:'Sabha',ar:'سبها'},{en:'Al Kufra',ar:'الكفره'},{en:'Al Aziziyah',ar:'العزيزية'},{en:'Gharyan',ar:'غريان'},{en:'Al Asaba',ar:'الاصابعه'},{en:'Kikla',ar:'ككله'},{en:'Yafran',ar:'يفرن'},{en:'Ar Rayaynah',ar:'الريانيه'},{en:'Zintan',ar:'الزنتان'},{en:'Ar Rajban',ar:'الرجبان'},{en:'Jadu',ar:'جادو'},{en:'Ar Ruhaybat',ar:'الرحيبات'},{en:'Al Josh',ar:'الجوش'},{en:'Jalu',ar:'جالو'},{en:'Awjila',ar:'اوجله'},{en:'Bani Walid',ar:'بني وليد'},{en:'Brak Al Shati',ar:'براك الشاطي'},{en:'Samnu',ar:'سمنه'},{en:'Ghudwah',ar:'غدوة'},{en:'Ubari',ar:'اوباري'},{en:'Tmassah',ar:'تمسه'},{en:'Al Awaynat',ar:'العوينات'},{en:'Ghat',ar:'غات'},{en:'Murzuq',ar:'مرزق'},{en:'Traghen',ar:'تراغن'},{en:'Zawiya',ar:'الزاوية'},{en:'Al Zahra',ar:'الزهراء'},{en:'Surman',ar:'صرمان'},{en:'Sabratha',ar:'صبراته'},{en:'Al Ajelat',ar:'العجيلات'},{en:'Al Jumayl',ar:'الجميل'},{en:'Zuwara',ar:'زواره'},{en:'Riqdalin',ar:'راقده لين'},{en:'Zaltan',ar:'زلطن'},{en:'Badr',ar:'بدر'},{en:'Tiji',ar:'تيجي'},{en:'Tamzin',ar:'طمزين'},{en:'Kabo',ar:'كابو'},{en:'Nalut',ar:'نالوت'},{en:'Wazzan',ar:'وزان'},{en:"Al Qal'ah",ar:'القلعه'},{en:"Al Sa'diyah",ar:'الساعديه'}];
function __cityLbl(en){try{if(typeof __ar==='function'&&__ar()){const m=LIBYA_CITIES.find(c=>c.en===en);if(m)return m.ar;}}catch(e){}return en;}
function __countryLbl(code){if(code==='LY')return __ar()?'ليبيا':'Libya';if(typeof COUNTRY_NAMES!=='undefined'&&COUNTRY_NAMES[code])return COUNTRY_NAMES[code];return code;}
function addCity(code,cityVal){let city=cityVal;if(!city){const id='new-city-'+code;const el=document.getElementById(id);city=el?el.value.trim():'';if(el)el.value='';}if(!city||!zones[code]||zones[code].cities[city])return;zones[code].cities[city]={delivery:''};renderZoneBuilderList();}
function removeCity(code,city){delete zones[code].cities[city];renderZoneBuilderList();}
function updateCityCost(code,city,field,val){if(zones[code]&&zones[code].cities[city])zones[code].cities[city][field]=parseFloat(val)||0;}
function updateZoneShipping(code,val){if(zones[code])zones[code].shipping=val===''?'':(parseFloat(val)||0);}
function renderZoneBuilderList(){const el=document.getElementById('zone-builder-list');const keys=Object.keys(zones);if(!keys.length){el.innerHTML='';return;}const ar=(typeof __ar==='function'&&__ar());const shipLblFor=(name)=>ar?`تكلفة الشحن لـ ${name} (اختياري)`:`Shipping cost for ${name} (optional)`;const cityLbl=ar?'المدينة':'City';const dlvLbl=ar?'تكلفة التوصيل':'Delivery cost';el.innerHTML=keys.map(code=>{const z=zones[code];const ck=Object.keys(z.cities);const isLY=code==='LY';const countryMeta=COUNTRIES.find(c=>c.code===code);const flag=countryMeta?countryMeta.flag:'\ud83c\udf10';const cname=__countryLbl(code);let adder;if(isLY){const avail=LIBYA_CITIES.filter(c=>!z.cities[c.en]);const placeholder=ar?'اختر مدينة…':'Select a city…';adder=`<select id="new-city-${code}" onchange="if(this.value){addCity('${code}',this.value);this.value='';}" style="width:100%;padding:11px 12px;font-size:13px;border:1.5px dashed var(--color-border-secondary);border-radius:12px;background:transparent;color:#34c77b;font-weight:700;outline:none;font-family:var(--font-sans);margin-top:10px;"><option value="">${placeholder}</option>${avail.map(c=>`<option value="${c.en.replace(/"/g,'&quot;')}">${__cityLbl(c.en)}</option>`).join('')}</select>`;}else{adder=`<div style="display:flex;gap:6px;margin-top:10px"><input id="new-city-${code}" type="text" placeholder="${ar?'أضف مدينة…':'Add a city…'}" style="flex:1;padding:9px 10px;font-size:13px;border:0.5px solid var(--color-border-secondary);border-radius:10px;background:var(--color-background-primary);color:var(--color-text-primary);outline:none;font-family:var(--font-sans);" onkeydown="if(event.key==='Enter'){event.preventDefault();addCity('${code}');}"/><button onclick="addCity('${code}')" style="height:38px;padding:0 14px;border-radius:10px;border:none;background:#34c77b;color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--font-sans);">${ar?'إضافة':'Add'}</button></div>`;}const shipRow=`<div class="lp-cost-row"><span class="cost-label">${shipLblFor(cname)}</span><input type="number" value="${z.shipping===''||z.shipping==null?'':z.shipping}" placeholder="0.00" step="0.01" onchange="updateZoneShipping('${code}',this.value)"/></div>`;const cityRows=ck.map(city=>`<div class="lp-city-row-flex"><span class="city-name">${isLY?__cityLbl(city):city} <span class="x-mark" onclick="removeCity('${code}','${city}')">✕</span></span><input type="number" value="${z.cities[city].delivery||''}" placeholder="0.00" step="0.01" onchange="updateCityCost('${code}','${city}','delivery',this.value)"/></div>`).join('');return`<div class="lp-country-card-2"><div class="lp-country-card-head"><span>${flag} ${cname}</span><span class="rm" onclick="removeZone('${code}')">✕</span></div>${shipRow}${ck.length?`<div class="lp-city-values-label"><span>${cityLbl}</span><span>${dlvLbl}</span></div>${cityRows}`:''}${adder}</div>`;}).join('');}
function hydrateVariantGroups(p){const __exPh=__ar()?'مثال: المقاس او اللون':'Example: color or size';const __valPh=__ar()?'مثال: أسود أو XL':'Black or XL';const __norm=v=>({id:variantIdCounter++,val:typeof v==='string'?v:(v&&v.val)||'',qty:(v&&typeof v==='object'&&v.qty)||'',photo:(v&&typeof v==='object'&&v.photo)||''});if(!p)return[{id:groupIdCounter++,name:'',placeholder:__exPh,valPlaceholder:__valPh,items:[{id:variantIdCounter++,val:'',qty:'',photo:''}]}];if(p.variantGroups&&p.variantGroups.length)return p.variantGroups.map(g=>({id:groupIdCounter++,name:g.name,placeholder:__exPh,valPlaceholder:__valPh,items:(g.items||[]).map(__norm)}));const out=[];if(p.sizes&&p.sizes.length)out.push({id:groupIdCounter++,name:__ar()?'المقاسات':'Sizes',placeholder:__exPh,valPlaceholder:__valPh,items:p.sizes.map(__norm)});if(p.colors&&p.colors.length)out.push({id:groupIdCounter++,name:__ar()?'الألوان':'Colours',placeholder:__exPh,valPlaceholder:__valPh,items:p.colors.map(__norm)});return out;}
function ensureUniqueCode(existing){let c=existing||genCode();const taken=new Set((products||[]).map(x=>x.code));let guard=0;while(taken.has(c)&&guard<50){c=genCode();guard++;}return c;}
function openAddForm(p){photos=p?[...(p.photos||[])]:[];variantGroups=hydrateVariantGroups(p);variantMode=variantGroups.length?'variants':'none';simpleQty=(p&&p.qty!=null&&Number(p.qty)>=0)?String(Math.round(Number(p.qty))):'0';zones=p?JSON.parse(JSON.stringify(p.delivery)):{};Object.keys(zones).forEach(code=>{const z=zones[code];if(!z.cities)z.cities={};let s=0;Object.values(z.cities).forEach(c=>{const cs=Number(c.shipping)||0;if(cs>s)s=cs;});if(z.shipping==null||z.shipping==='')z.shipping=s||'';});commMode=p?.commMode||'pct';selectedCurrency=p?.currency||__defaultCurrencyForCountry();currentCode=ensureUniqueCode(p?.code);document.getElementById('product-code-display').textContent=currentCode;document.getElementById('form-title').textContent=p?'Edit product':'Add a product';document.getElementById('f-name').value=p?.name||'';document.getElementById('f-desc').value=p?.desc||'';document.getElementById('f-price').value=p?.price||'';document.getElementById('f-cost').value=p?.costPrice||'';selectedCategory=p?.category||'';const catVal=document.getElementById('category-picker-value');if(selectedCategory){catVal.textContent=__ar()?(CATEGORY_ITEM_AR[selectedCategory]||selectedCategory):selectedCategory;catVal.classList.remove('placeholder');}else{catVal.textContent='Select category';catVal.classList.add('placeholder');}document.getElementById('f-comm-pct').value=p?.commPct||'';document.getElementById('f-comm-fixed').value=p?.commFixed||'';if(selectedCurrency){document.getElementById('curr-flag').textContent=selectedCurrency.flag;document.getElementById('curr-name').textContent=selectedCurrency.name+' ('+selectedCurrency.code+')';document.getElementById('curr-symbol-label').textContent=selectedCurrency.symbol;document.getElementById('price-prefix').textContent=selectedCurrency.symbol;}else{document.getElementById('curr-flag').textContent='🌐';document.getElementById('curr-name').textContent='Select a currency';document.getElementById('curr-symbol-label').textContent='';document.getElementById('price-prefix').textContent='—';}updateCommFixedUnitLabel();setCommMode(commMode);renderPhotoGrid();renderVariantGroups();setVariantMode(variantMode);{const __sq=document.getElementById('f-simple-qty');if(__sq){const __v=parseInt(simpleQty||'0',10);__sq.value=String(!Number.isFinite(__v)||__v<0?0:__v);}}renderZoneBuilderList();updateConversionNote();updateProductSummaryCard();document.getElementById('form-overlay').classList.add('open');}
function closeForm(){document.getElementById('form-overlay').classList.remove('open');editingId=null;photos=[];variantGroups=[];variantMode='none';simpleQty='';zones={};selectedCurrency=null;selectedCategory='';currDropdownOpen=false;countryDropdownOpen=false;closeCategoryPanel();}
/* legacy submitProduct removed — see async version below */
/* MY PRODUCTS v2 — card rendering (real data, mp- prefixed) */
const LOW_STOCK_THRESHOLD=20;
// True remaining stock for a product: when it has per-variant quantities
// tracked, trust their sum over the top-level qty field, which can go out
// of sync with the real variant counts. Falls back to the raw qty when no
// variant quantities are tracked (simple/no-variant products).
function __mpEffectiveQty(p){
  const groups=(p&&p.variantGroups)||[];
  let total=0,tracked=false;
  groups.forEach(g=>(g&&g.items||[]).forEach(it=>{
    const q=it&&it.qty;
    if(q!==null&&q!==undefined&&q!==''&&Number.isFinite(Number(q))){tracked=true;total+=Math.max(0,Number(q));}
  }));
  return tracked?total:(Number(p&&p.qty)||0);
}
let mpActiveFilter='all';
const mpPhotoIndex={};
const mpAnalyticsOpen={};
const mpPeriod={};
const __mpBdSelected={};
function __mpInPeriod(createdAt,period){
  if(period==='all')return true;
  if(!createdAt)return false;
  const c=createdAt instanceof Date?createdAt:new Date(createdAt);
  if(isNaN(c))return false;
  const now=new Date();
  if(period==='day')return c.getFullYear()===now.getFullYear()&&c.getMonth()===now.getMonth()&&c.getDate()===now.getDate();
  if(period==='month')return c.getFullYear()===now.getFullYear()&&c.getMonth()===now.getMonth();
  if(period==='year')return c.getFullYear()===now.getFullYear();
  return true;
}
function __mpInSel(createdAt,sel){
  if(!sel||(!sel.day&&!sel.month&&!sel.year))return true;
  if(!createdAt)return false;
  const c=createdAt instanceof Date?createdAt:new Date(createdAt);
  if(isNaN(c))return false;
  if(sel.day&&__bdDays[c.getDay()]!==sel.day)return false;
  if(sel.month&&__bdMonths[c.getMonth()]!==sel.month)return false;
  if(sel.year&&String(c.getFullYear())!==sel.year)return false;
  return true;
}
function mpProductOrders(p,sel){
  try{
    if(typeof orders==='undefined'||!Array.isArray(orders))return[];
    return orders.filter(o=>o.productId===p.id&&o._status==='delivered'&&__mpInSel(o._createdAt,sel));
  }catch(e){return[];}
}
function mpOrderNet(o){return(Number(o.price)||0)*(Number(o.qty)||0)-(Number(o.commission)||0)-(Number(o.platformFee)||0);}

function mpEsc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

function mpFmt(p){const sym=p.currency?__wrapArSym(p.currency.symbol,p.currency.code):'';return (n)=>__moneyH(n,sym,p.currency&&p.currency.code);}

function mpSetFilter(key,el){mpActiveFilter=key;document.querySelectorAll('.mp-filter-chip').forEach(c=>c.classList.toggle('active',c===el));renderProducts();}

function mpStatusBadges(p){
  const b=[];
  const eq=__mpEffectiveQty(p);
  if(p.status==='active')b.push(`<span class="mp-status-pill mp-status-active"><span class="mp-dot-ind"></span>${__ar()?'نشط':'Active'}</span>`);
  else b.push(`<span class="mp-status-pill mp-status-inactive"><span class="mp-dot-ind"></span>${__ar()?'متوقف':'Paused'}</span>`);
  if(eq===0)b.push(`<span class="mp-status-pill mp-status-outofstock"><span class="mp-dot-ind"></span>${__ar()?'نفدت الكمية':'Out of stock'}</span>`);
  else if(eq>0&&eq<=LOW_STOCK_THRESHOLD)b.push(`<span class="mp-status-pill mp-status-lowstock"><span class="mp-dot-ind"></span>${__ar()?'كمية منخفضة':'Low stock'}</span>`);
  return b.join('');
}

function mpSlidesHtml(p){
  const photos=(p.photos||[]).filter(Boolean);
  if(!photos.length){
    const icon=p.currency?(p.currency.flag||'📦'):'📦';
    return `<div class="mp-p-thumb-slide mp-p-thumb-empty">${icon}</div>`;
  }
  return photos.map(url=>`<div class="mp-p-thumb-slide"><img src="${mpEsc(url)}" alt="${mpEsc(p.name)}" loading="eager" decoding="async" onerror="this.onerror=null;this.parentElement.classList.add('mp-p-thumb-empty');this.replaceWith(Object.assign(document.createElement('span'),{textContent:'📦'}));"/></div>`).join('');
}

function mpDotsHtml(p){
  const photos=(p.photos||[]).filter(Boolean);
  if(photos.length<=1)return '';
  const dots=photos.map((_,i)=>`<span class="mp-thumb-dot${i===0?' active':''}" onclick="event.stopPropagation();mpSlidePhoto('${p.id}',${i})"></span>`).join('');
  return `<div class="mp-thumb-dots">${dots}</div>`;
}

function mpAnalyticsSection(p){
  const sel=__mpBdSelected[p.id]||(__mpBdSelected[p.id]={day:null,month:null,year:null});
  const anySel=!!(sel.day||sel.month||sel.year);
  const dayLbl=sel.day||(__ar()?'يوم':'Day');
  const monthLbl=sel.month||(__ar()?'شهر':'Month');
  const yearLbl=sel.year||(__ar()?'سنة':'Year');
  setTimeout(()=>__mpBdInitFor(p.id),0);
  return `<div class="mp-analytics-panel-inner">
    <div class="bd-range-tabs mp-bd-range-tabs" id="mp-bd-tabs-${p.id}" onclick="event.stopPropagation();">
      <div class="bd-range-tab${!anySel?' active':''}" data-range="all" data-pid="${p.id}" onclick="mpBdTabClick('${p.id}','all',this)">${__ar()?'كل الوقت':'All time'}</div>
      <div class="bd-range-tab${sel.day?' active':''}" data-range="daily" data-pid="${p.id}" onclick="mpBdTabClick('${p.id}','daily',this)">${dayLbl} <span class="bd-chev">▾</span></div>
      <div class="bd-range-tab${sel.month?' active':''}" data-range="monthly" data-pid="${p.id}" onclick="mpBdTabClick('${p.id}','monthly',this)">${monthLbl} <span class="bd-chev">▾</span></div>
      <div class="bd-range-tab${sel.year?' active':''}" data-range="yearly" data-pid="${p.id}" onclick="mpBdTabClick('${p.id}','yearly',this)">${yearLbl} <span class="bd-chev">▾</span></div>
    </div>
    <div class="bd-dropdown-list" id="mp-bd-daily-list-${p.id}" onclick="event.stopPropagation();"></div>
    <div class="bd-dropdown-list" id="mp-bd-monthly-list-${p.id}" onclick="event.stopPropagation();"></div>
    <div class="bd-dropdown-list" id="mp-bd-yearly-list-${p.id}" onclick="event.stopPropagation();"></div>
    <div id="mp-analytics-body-${p.id}">${mpAnalyticsBody(p,sel)}</div>
  </div>`;
}
// --- Per-product analytics date tabs: same tab+dropdown widget as the wallet
// "Breakdown" screen (__bd*), scoped per product id so several product cards
// can each have their own independent day/month/year selection open at once.
function __mpBdUpdateTabLabel(pid,filterKey){
  const rangeName=filterKey==='day'?'daily':filterKey==='month'?'monthly':'yearly';
  const tab=document.querySelector(`.bd-range-tab[data-range="${rangeName}"][data-pid="${pid}"]`);
  if(!tab)return;
  const sel=__mpBdSelected[pid]||{};
  const val=sel[filterKey];
  const defaultLabel=filterKey==='day'?(__ar()?'يوم':'Day'):filterKey==='month'?(__ar()?'شهر':'Month'):(__ar()?'سنة':'Year');
  tab.innerHTML=(val?val:defaultLabel)+' <span class="bd-chev">▾</span>';
  tab.classList.toggle('active',!!val);
  const allTab=document.querySelector(`.bd-range-tab[data-range="all"][data-pid="${pid}"]`);
  if(allTab){const s=__mpBdSelected[pid]||{};allTab.classList.toggle('active',!(s.day||s.month||s.year));}
}
function __mpBdCloseDropdown(pid,rangeName){
  const list=document.getElementById(`mp-bd-${rangeName}-list-${pid}`);
  if(list)list.classList.remove('open');
  const tab=document.querySelector(`.bd-range-tab[data-range="${rangeName}"][data-pid="${pid}"]`);
  if(tab)tab.classList.remove('open');
}
function __mpBdCloseAllDropdowns(pid){['daily','monthly','yearly'].forEach(r=>__mpBdCloseDropdown(pid,r));}
function __mpBdBuildDropdown(pid,listEl,keys,filterKey,rangeName){
  if(!listEl)return;
  listEl.innerHTML='';
  const clearItem=document.createElement('div');
  clearItem.className='bd-dd-item clear';
  clearItem.textContent=__ar()?'إلغاء التحديد':'Clear selection';
  clearItem.addEventListener('click',e=>{e.stopPropagation();const sel=__mpBdSelected[pid]||(__mpBdSelected[pid]={day:null,month:null,year:null});sel[filterKey]=null;__mpBdUpdateTabLabel(pid,filterKey);__mpBdCloseDropdown(pid,rangeName);mpRefreshAnalyticsBody(pid);});
  listEl.appendChild(clearItem);
  keys.forEach(key=>{
    const item=document.createElement('div');
    item.className='bd-dd-item';
    item.textContent=key;
    item.addEventListener('click',e=>{e.stopPropagation();const sel=__mpBdSelected[pid]||(__mpBdSelected[pid]={day:null,month:null,year:null});sel[filterKey]=key;__mpBdUpdateTabLabel(pid,filterKey);__mpBdCloseDropdown(pid,rangeName);mpRefreshAnalyticsBody(pid);});
    listEl.appendChild(item);
  });
}
function mpBdTabClick(pid,range,tabEl){
  if(range==='all'){
    __mpBdCloseAllDropdowns(pid);
    __mpBdSelected[pid]={day:null,month:null,year:null};
    ['day','month','year'].forEach(k=>__mpBdUpdateTabLabel(pid,k));
    const allTab=document.querySelector(`.bd-range-tab[data-range="all"][data-pid="${pid}"]`);
    if(allTab)allTab.classList.add('active');
    mpRefreshAnalyticsBody(pid);
    return;
  }
  const listEl=document.getElementById(`mp-bd-${range}-list-${pid}`);
  if(!listEl)return;
  const isOpen=listEl.classList.contains('open');
  __mpBdCloseAllDropdowns(pid);
  if(!isOpen){listEl.classList.add('open');tabEl.classList.add('open');}
}
let __mpBdGlobalClickBound=false;
function __mpBdInitFor(pid){
  if(!document.getElementById(`mp-bd-daily-list-${pid}`))return;
  __mpBdSelected[pid]=__mpBdSelected[pid]||{day:null,month:null,year:null};
  const curYear=new Date().getFullYear();
  const yrs=[curYear-2,curYear-1,curYear].map(String);
  __mpBdBuildDropdown(pid,document.getElementById(`mp-bd-daily-list-${pid}`),__bdDays,'day','daily');
  __mpBdBuildDropdown(pid,document.getElementById(`mp-bd-monthly-list-${pid}`),__bdMonths,'month','monthly');
  __mpBdBuildDropdown(pid,document.getElementById(`mp-bd-yearly-list-${pid}`),yrs,'year','yearly');
  if(!__mpBdGlobalClickBound){
    __mpBdGlobalClickBound=true;
    document.addEventListener('click',e=>{
      if(!e.target.closest('.bd-range-tab')&&!e.target.closest('.bd-dropdown-list')){
        document.querySelectorAll('.mp-bd-range-tabs ~ .bd-dropdown-list.open, .bd-dropdown-list.open').forEach(l=>l.classList.remove('open'));
        document.querySelectorAll('.bd-range-tab.open').forEach(t=>t.classList.remove('open'));
      }
    });
  }
}
function mpRefreshAnalyticsBody(pid){
  const p=(typeof products!=='undefined'?products:[]).find(x=>x.id===pid);if(!p)return;
  const body=document.getElementById(`mp-analytics-body-${pid}`);
  if(body)body.innerHTML=mpAnalyticsBody(p,__mpBdSelected[pid]);
}

function mpAnalyticsBody(p,sel){
  const fmtP=mpFmt(p);
  const list=mpProductOrders(p,sel);
  const sold=list.reduce((s,o)=>s+(Number(o.qty)||0),0);
  const revenue=list.reduce((s,o)=>s+mpOrderNet(o),0);
  const eq=__mpEffectiveQty(p);
  const stockClass=eq===0?'warn':(eq<=LOW_STOCK_THRESHOLD?'warn':'accent');
  return `
    <div class="mp-stat-grid">
      <div class="mp-stat-tile"><div class="mp-stat-label">${__ar()?'إجمالي المباع':'Total sold'}</div><div class="mp-stat-val">${sold.toLocaleString()}</div></div>
      <div class="mp-stat-tile ${stockClass}"><div class="mp-stat-label">${__ar()?'إجمالي المخزون':'Total stock'}</div><div class="mp-stat-val">${eq||0}</div></div>
      <div class="mp-stat-tile"><div class="mp-stat-label">${__ar()?'إجمالي الإيرادات':'Total revenue'}</div><div class="mp-stat-val">${fmtP(revenue)}</div></div>
    </div>
    ${mpVariantBoxes(p,sel,list)}`;
}

function mpSetPeriod(pid,period){
  const p=products.find(x=>x.id===pid);if(!p)return;
  mpPeriod[pid]=period;
  document.querySelectorAll(`.mp-period-chip[data-pid="${pid}"]`).forEach(el=>el.classList.toggle('sel',el.dataset.period===period));
  const body=document.getElementById(`mp-analytics-body-${pid}`);
  if(body)body.innerHTML=mpAnalyticsBody(p,period);
}

function mpVariantBoxes(p,sel,list){
  list=list||mpProductOrders(p,sel);
  const fmtP=mpFmt(p);
  const realGroups=(p.variantGroups||[]).filter(g=>g.items&&g.items.length);
  if(realGroups.length){
    return realGroups.map(g=>{
      const items=g.items;
      const total=items.reduce((s,x)=>s+(Number(x.qty)||0),0);
      const maxQty=Math.max(...items.map(x=>Number(x.qty)||0),1);
      const rows=items.map(x=>{
        const qty=Number(x.qty)||0;
        const pct=Math.max(6,Math.round(qty/maxQty*100));
        const low=qty===0?'mp-empty':(qty<=LOW_STOCK_THRESHOLD?'mp-low':'');
        const swatch=x.photo?`<img class="mp-vg-swatch" src="${mpEsc(x.photo)}" alt="" onclick="event.stopPropagation();mpOpenLightbox(['${mpEsc(x.photo)}'],0)"/>`:'';
        // Attribute sold/revenue only to the variant value that was actually
        // ordered — never split a sale proportionally across sibling values.
        const vList=list.filter(o=>o.size===x.val||o.color===x.val);
        const vSold=vList.reduce((s,o)=>s+(Number(o.qty)||0),0);
        const vRevenue=vList.reduce((s,o)=>s+mpOrderNet(o),0);
        return `<div class="mp-vg-value-row">
          <div class="mp-vg-value-top">
            ${swatch}
            <span class="mp-vg-value-name">${mpEsc(x.val)}</span>
            <div class="mp-vg-bar-track"><div class="mp-vg-bar-fill ${low}" style="width:${pct}%"></div></div>
          </div>
          <div class="mp-vg-mini-grid">
            <div class="mp-vg-mini ${low?'warn':''}"><div class="l">${__ar()?'المخزون':'In stock'}</div><div class="v">${qty}</div></div>
            <div class="mp-vg-mini"><div class="l">${__ar()?'المباع':'Sold'}</div><div class="v">${vSold}</div></div>
            <div class="mp-vg-mini"><div class="l">${__ar()?'الإيرادات':'Revenue'}</div><div class="v">${fmtP(vRevenue)}</div></div>
          </div>
        </div>`;
      }).join('');
      return `<div class="mp-variant-group-box">
        <div class="mp-vg-title-row"><span class="mp-vg-title">${mpEsc(g.name||'Variant')}</span><span class="mp-vg-total">${total} ${__ar()?'بالمخزون':'in stock'}</span></div>
        ${rows}
      </div>`;
    }).join('');
  }
  const chips=[];
  if(p.sizes&&p.sizes.length)chips.push(...p.sizes.map(v=>`<span class="mp-variant-chip">${__ar()?'المقاس':'Size'}: ${mpEsc(v)}</span>`));
  if(p.colors&&p.colors.length)chips.push(...p.colors.map(v=>`<span class="mp-variant-chip">${__ar()?'اللون':'Colour'}: ${mpEsc(v)}</span>`));
  if(!chips.length)return '';
  return `<div class="mp-variant-chip-row">${chips.join('')}</div>`;
}

// Active Marketers (per product) — shown only in the Marketer info fold below.
// = number of DISTINCT marketers with at least one order on this product whose
// status is pending, approved, or confirmed (i.e. approved-but-not-yet-delivered
// from the marketer's side). Delivered / rejected / cancelled(failed) orders never
// count. Dedup is by marketer id (a Set), not by order count, so 5 pending orders
// from the same marketer still counts as 1. This recomputes from scratch off the
// live `orders` array every time it's called (no stored counter to drift), and
// `orders` itself is kept fresh by the realtime 'orders' subscription elsewhere in
// this file — so the moment a qualifying order is delivered/rejected/failed, the
// next render already reflects the drop (and leaves the count unchanged if that
// marketer still has another qualifying order for the same product).
function mpActiveMarketerCount(p){
  try{
    if(typeof orders==='undefined'||!Array.isArray(orders))return 0;
    const pool=orders.concat(__pendingActiveStubs||[]);
    const ids=new Set(pool.filter(o=>o.productId===p.id&&o.marketerId&&__ACTIVE_MKT_STATUSES.has(o._status)).map(o=>o.marketerId));
    return ids.size;
  }catch(e){return 0;}
}

function mpMarketerFold(p){
  const fmtP=mpFmt(p);
  const feeLabel=p.commMode==='fixed'?fmtP(p.commFixed||0):`${p.commPct||0}%`;
  const activeMarketers=mpActiveMarketerCount(p);
  return `<div class="mp-fold-section mp-marketer-fold">
    <div class="mp-fold-head" onclick="event.stopPropagation();mpToggleFold('marketer-${p.id}')">
      <div><div class="mp-fold-label">${__ar()?'معلومات المسوّق':'Marketer info'}</div></div>
      <svg class="mp-fold-chevron" id="mp-chev-marketer-${p.id}" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </div>
    <div class="mp-fold-body" id="mp-fold-marketer-${p.id}">
      <div class="mp-fold-body-inner">
        <div class="mp-mb-grid">
          <div class="mp-mb-tile"><div class="l">${__ar()?'عمولة المسوّق':'Marketer fee'}</div><div class="v">${feeLabel}</div></div>
          <div class="mp-mb-tile"><div class="l">${__ar()?'أرباح البيع الواحد':'Earnings per sale'}</div><div class="v">${fmtP(p.commFixed||0)}</div></div>
          <div class="mp-mb-tile"><div class="l">${__ar()?'المسوّقون النشطون':'Active marketers'}</div><div class="v">${activeMarketers}</div></div>
        </div>
      </div>
    </div>
  </div>`;
}

function mpShippingFold(p){
  const codes=Object.keys(p.delivery||{});
  if(!codes.length)return '';
  const fmtP=mpFmt(p);
  const boxes=codes.map(code=>{
    const z=p.delivery[code]||{};const cities=z.cities||{};
    const rows=Object.entries(cities).map(([city,c])=>`<div class="mp-city-row"><span><b>${mpEsc(__cityLbl(city))}</b></span><span class="mp-dfee">${__ar()?'التوصيل':'Delivery'} <b>${fmtP((c&&c.delivery)||0)}</b></span></div>`).join('');
    return `<div class="mp-country-box">
      <div class="mp-country-head">
        <span class="mp-cname">${COUNTRY_FLAGS[code]||'🌐'} ${mpEsc(__countryLbl(code))}</span>
        <span class="mp-cship">${__ar()?'الشحن':'Shipping'}<br><b>${fmtP(z.shipping||0)}</b></span>
      </div>
      ${rows}
    </div>`;
  }).join('');
  return `<div class="mp-fold-section">
    <div class="mp-fold-head" onclick="event.stopPropagation();mpToggleFold('shipping-${p.id}')">
      <div><div class="mp-fold-label">${__ar()?'الشحن والتوصيل':'Shipping & delivery'}</div><div class="mp-fold-sub">${__ar()?(codes.length===1?'دولة واحده':codes.length===2?'دولتين':codes.length+' دول'):(codes.length+' '+(codes.length===1?'country':'countries'))}</div></div>
      <svg class="mp-fold-chevron" id="mp-chev-shipping-${p.id}" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </div>
    <div class="mp-fold-body" id="mp-fold-shipping-${p.id}">
      <div class="mp-fold-body-inner">${boxes}</div>
    </div>
  </div>`;
}

function mpReviewsFold(p){
  const list=(window.__bizReviewsByProduct&&window.__bizReviewsByProduct[p.id])||[];
  const sub=list.length?`${(list.reduce((s,r)=>s+(Number(r.rating)||0),0)/list.length).toFixed(1)} ★ · ${list.length} ${__ar()?'تقييم':'reviews'}`:(__ar()?'لا توجد تقييمات بعد':'No reviews yet');
  const body=list.length
    ?list.map(r=>{const stars=Math.max(0,Math.min(5,Number(r.rating)||0));return `<div class="mp-review-item"><div class="mp-review-top"><span class="mp-review-name">${mpEsc(r.author||'Marketer')}</span><span class="mp-review-stars">${'★'.repeat(stars)}${'☆'.repeat(5-stars)}</span></div>${r.text?`<div class="mp-review-text">${mpEsc(r.text)}</div>`:''}</div>`;}).join('')
    :`<div class="mp-empty-note">${__ar()?'ستظهر التقييمات هنا بعد نشر المنتج وبيعه.':'Reviews will show up here once this product is published and sold.'}</div>`;
  return `<div class="mp-fold-section">
    <div class="mp-fold-head" onclick="event.stopPropagation();mpToggleFold('reviews-${p.id}')">
      <div><div class="mp-fold-label">${__ar()?'التقييمات':'Reviews'}</div><div class="mp-fold-sub">${sub}</div></div>
      <svg class="mp-fold-chevron" id="mp-chev-reviews-${p.id}" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </div>
    <div class="mp-fold-body" id="mp-fold-reviews-${p.id}">
      <div class="mp-fold-body-inner">${body}</div>
    </div>
  </div>`;
}

const MP_ICON_EDIT=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M15 5l4 4L7 21H3v-4L15 5z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M13 7l4 4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>`;
const MP_ICON_TRASH=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 7h14" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M9 7V4.5h6V7" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M10 11v6M14 11v6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><rect x="4" y="7" width="16" height="13" rx="2" stroke="currentColor" stroke-width="1.4"/></svg>`;

function mpActionsRow(p){
  const primaryLabel=p.status==='active'?(__ar()?'إيقاف':'Pause'):(__ar()?'تفعيل':'Activate');
  return `<div class="mp-action-row">
    <div class="mp-icon-btn" title="Edit" onclick="event.stopPropagation();editProduct('${p.id}')">${MP_ICON_EDIT}</div>
    <div class="mp-action-btn ${p.status==='active'?'warn':'primary'}" onclick="event.stopPropagation();toggleStatus('${p.id}')">${primaryLabel}</div>
    <div class="mp-icon-btn mp-danger" title="Delete" onclick="event.stopPropagation();deleteProduct('${p.id}')">${MP_ICON_TRASH}</div>
  </div>`;
}

function mpRenderCard(p){
  const fmtP=mpFmt(p);
  const eq=__mpEffectiveQty(p);
  return `<div class="mp-product-card" data-id="${p.id}">
    <div class="mp-p-head" onclick="mpToggleCard('${p.id}')">
      <div class="mp-p-thumb-wrap" id="mp-thumb-wrap-${p.id}" onclick="event.stopPropagation();mpOpenLightbox('${p.id}')">
        <div class="mp-p-thumb" id="mp-thumb-${p.id}">
          <div class="mp-p-thumb-track" id="mp-thumb-track-${p.id}">${mpSlidesHtml(p)}</div>
          ${p.category?`<span class="mp-thumb-category" data-no-i18n>${mpEsc(mpCategoryLabel(p.category))}</span>`:''}
          ${mpDotsHtml(p)}
        </div>
      </div>
      <div class="mp-p-info">
        <p class="mp-p-name-collapsed">${mpEsc(p.name)}</p>
        <span class="mp-p-price-collapsed">${fmtP(p.price)}</span>
      </div>
      <div class="mp-p-status-strip">${mpStatusBadges(p)}</div>
      <div class="mp-p-code-corner">
        <span class="mp-code-label">${__ar()?'كود المنتج':'Product code'}</span>
        <span class="mp-code-val">${mpEsc(p.code)}</span>
      </div>
      <div class="mp-p-chevron">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </div>
      <div class="mp-p-info-expanded">
        <div class="mp-p-name-price-row">
          <p class="mp-p-name-exp">${mpEsc(p.name)}</p>
          <span class="mp-p-price-exp">${fmtP(p.price)}</span>
        </div>
        ${p.desc?`<p class="mp-p-desc-exp">${mpEsc(p.desc)}</p>`:''}
      </div>
    </div>
    ${eq===0?`<div class="mp-oos-banner">${__ar()?'أكتب الكميه لعرض منتجك للمسوّقين':'Enter the quantity to show your product to marketers'}</div>`:''}
    <div class="mp-p-details">
      <div class="mp-p-details-inner">
        <div class="mp-divider"></div>
        <div class="mp-details-top-row">
          <div class="mp-details-code-pill">
            <span class="mp-code-label">${__ar()?'كود المنتج':'Product code'}</span>
            <span class="mp-code-val">${mpEsc(p.code)}</span>
          </div>
          <div class="mp-analytics-btn-outer" id="mp-abtn-${p.id}" onclick="event.stopPropagation();mpToggleAnalytics('${p.id}')">
            <div class="mp-analytics-icon"><span style="height:5px;opacity:.5"></span><span style="height:9px;opacity:.7"></span><span style="height:13px"></span></div>
            <span class="mp-analytics-btn-label">${__ar()?'التحليلات':'Analytics'}</span>
            <svg class="mp-analytics-chev" width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </div>
        </div>
        <div class="mp-analytics-panel" id="mp-analytics-panel-${p.id}">${mpAnalyticsSection(p)}</div>
        ${mpMarketerFold(p)}
        ${mpShippingFold(p)}
        ${mpReviewsFold(p)}
        ${mpActionsRow(p)}
      </div>
    </div>
  </div>`;
}

function mpToggleCard(id){const card=document.querySelector(`.mp-product-card[data-id="${id}"]`);if(card)card.classList.toggle('expanded');}

function mpToggleFold(key){const body=document.getElementById(`mp-fold-${key}`);const chev=document.getElementById(`mp-chev-${key}`);if(body)body.classList.toggle('open');if(chev)chev.classList.toggle('open');}

function mpToggleAnalytics(pid){mpAnalyticsOpen[pid]=!mpAnalyticsOpen[pid];const btn=document.getElementById(`mp-abtn-${pid}`);const panel=document.getElementById(`mp-analytics-panel-${pid}`);if(btn)btn.classList.toggle('open',mpAnalyticsOpen[pid]);if(panel)panel.classList.toggle('open',mpAnalyticsOpen[pid]);}

function mpSlidePhoto(pid,idx){
  const p=products.find(x=>x.id===pid);if(!p||!p.photos)return;
  mpPhotoIndex[pid]=idx;
  const track=document.getElementById(`mp-thumb-track-${pid}`);
  const __dir=(typeof __ar==='function'&&__ar())?1:-1;
  if(track)track.style.transform=`translateX(${__dir*idx*100}%)`;
  document.querySelectorAll(`.mp-product-card[data-id="${pid}"] .mp-thumb-dot`).forEach((d,i)=>{d.classList.toggle('active',i===idx);});
}

function mpInitSwipe(pid){
  const wrap=document.getElementById(`mp-thumb-${pid}`);
  if(!wrap||wrap.__mpSwipeBound)return;
  wrap.__mpSwipeBound=true;
  let startX=0,startY=0,dragging=false;
  wrap.addEventListener('touchstart',e=>{startX=e.touches[0].clientX;startY=e.touches[0].clientY;dragging=true;},{passive:true});
  wrap.addEventListener('touchend',e=>{
    if(!dragging)return;dragging=false;
    const dx=e.changedTouches[0].clientX-startX;
    const dy=e.changedTouches[0].clientY-startY;
    if(Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>40){
      const p=products.find(x=>x.id===pid);
      if(!p||!p.photos)return;
      const cur=mpPhotoIndex[pid]||0;
      const next=dx<0?Math.min(cur+1,p.photos.length-1):Math.max(cur-1,0);
      mpSlidePhoto(pid,next);
    }
  },{passive:true});
}

/* ── Fullscreen photo lightbox (product photos + variant swatches) ── */
let __mpLightboxPhotos=[];
let __mpLightboxIdx=0;

function mpOpenLightbox(arg,idx){
  let photos;
  const p=typeof arg==='string'?products.find(x=>x.id===arg):null;
  if(p){
    photos=(p.photos||[]).filter(Boolean);
    idx=mpPhotoIndex[arg]||0;
  }else if(Array.isArray(arg)){
    photos=arg.filter(Boolean);
  }else{
    photos=[String(arg)];
  }
  if(!photos.length)return;
  __mpLightboxPhotos=photos;
  __mpLightboxIdx=Math.min(Math.max(idx||0,0),photos.length-1);
  mpRenderLightbox();
  const ov=document.getElementById('mp-lightbox-overlay');
  if(ov)ov.classList.add('open');
  document.body.style.overflow='hidden';
}

function mpCloseLightbox(){
  const ov=document.getElementById('mp-lightbox-overlay');
  if(ov)ov.classList.remove('open');
  document.body.style.overflow='';
}

function mpLightboxGo(delta){
  __mpLightboxIdx=Math.min(Math.max(__mpLightboxIdx+delta,0),__mpLightboxPhotos.length-1);
  mpRenderLightbox();
}

function mpRenderLightbox(){
  const track=document.getElementById('mp-lightbox-track');
  const dots=document.getElementById('mp-lightbox-dots');
  const nav=document.getElementById('mp-lightbox-nav');
  if(!track)return;
  track.innerHTML=__mpLightboxPhotos.map(u=>`<div class="mp-lightbox-slide"><img src="${mpEsc(u)}" alt=""/></div>`).join('');
  track.style.transform=`translateX(-${__mpLightboxIdx*(100/__mpLightboxPhotos.length)}%)`;
  track.style.width=`${__mpLightboxPhotos.length*100}%`;
  track.querySelectorAll('.mp-lightbox-slide').forEach(s=>{s.style.width=`${100/__mpLightboxPhotos.length}%`;});
  if(dots)dots.innerHTML=__mpLightboxPhotos.length>1?__mpLightboxPhotos.map((_,i)=>`<span class="mp-lightbox-dot${i===__mpLightboxIdx?' active':''}" onclick="event.stopPropagation();__mpLightboxIdx=${i};mpRenderLightbox();"></span>`).join(''):'';
  if(nav)nav.style.display=__mpLightboxPhotos.length>1?'flex':'none';
  mpBindLightboxSwipe();
}

function mpBindLightboxSwipe(){
  const track=document.getElementById('mp-lightbox-track');
  if(!track||track.__mpSwipeBound)return;
  track.__mpSwipeBound=true;
  let startX=0,startY=0,dragging=false;
  track.addEventListener('touchstart',e=>{startX=e.touches[0].clientX;startY=e.touches[0].clientY;dragging=true;},{passive:true});
  track.addEventListener('touchend',e=>{
    if(!dragging)return;dragging=false;
    const dx=e.changedTouches[0].clientX-startX;
    const dy=e.changedTouches[0].clientY-startY;
    if(Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>40)mpLightboxGo(dx<0?1:-1);
  },{passive:true});
}

let __submittingProduct=false;
async function submitProduct(){if(__submittingProduct)return;if(__frozenBlock())return;const btn=document.querySelector('#form-overlay .submit-btn');const name=document.getElementById('f-name').value.trim();const price=parseFloat(document.getElementById('f-price').value)||0;const costPrice=parseFloat(document.getElementById('f-cost').value)||0;const commPct=parseFloat(document.getElementById('f-comm-pct').value)||0;const commFixed=parseFloat(document.getElementById('f-comm-fixed').value)||0;console.log('[Lateen] submitProduct fired',{name,price,costPrice,commPct,commFixed,selectedCurrency,zones});if(!name||!price||(!commPct&&!commFixed)){alert('Please fill in name, price and commission.');return;}if(!document.getElementById('f-desc').value.trim()){alert('Please add a product description.');return;}if(!selectedCategory){alert('Please select a category.');return;}if(!photos.length){alert('Please add at least one product photo.');return;}if(!selectedCurrency){alert('Please select a currency.');return;}if(variantMode==='none'){if(simpleQty===''||simpleQty==null||isNaN(Number(simpleQty))||Number(simpleQty)<0){alert(__ar()?'يرجى إدخال كمية صحيحة.':'Please enter a valid quantity.');return;}}else{for(const __vg of variantGroups){const __vgName=(__vg.name||'').trim();const __vgItems=__vg.items||[];const __vgBlank=__vgItems.filter(__it=>!(__it.val||'').toString().trim());const __vgFilled=__vgItems.filter(__it=>(__it.val||'').toString().trim());const __vgIsEmpty=!__vgName&&!__vgFilled.length;if(__vgIsEmpty)continue;if(__vgBlank.length){alert('Please fill in a value for every variant you add, or remove the empty one.');return;}if(!__vgFilled.length){alert('Please add at least one value for the "'+(__vgName||'variant')+'" variant, or remove it.');return;}const __vgNoQty=__vgFilled.filter(__it=>__it.qty===''||__it.qty==null||isNaN(Number(__it.qty)));if(__vgNoQty.length){alert(__ar()?'يرجى إدخال الكمية لكل قيمة.':'Please enter a quantity for every variant value.');return;}}}if(!Object.keys(zones).length){alert('Please add at least one delivery zone.');return;}const validZones={};for(const[code,z]of Object.entries(zones)){const zShip=Number(z.shipping)||0;const vc={};for(const[city,costs]of Object.entries(z.cities||{})){const dlv=Number(costs.delivery)||0;if(dlv>0)vc[city]={shipping:zShip,delivery:dlv};}if(Object.keys(vc).length)validZones[code]={cities:vc,shipping:zShip};}if(!Object.keys(validZones).length){alert('Please add at least one city with a delivery price.');return;}currentCode=ensureUniqueCode(editingId?currentCode:null);__submittingProduct=true;if(btn){btn.disabled=true;btn.style.opacity='0.6';btn.style.pointerEvents='none';btn.dataset.origText=btn.textContent;btn.textContent='Uploading photos…';}try{await __waitForProductPhotoUploads();const{comm,platform,total,commPct:finalPct}=calcFees(price,commPct,commFixed,commMode);const cleanGroups=variantMode==='variants'?variantGroups.map(g=>({name:(g.name||'Variant').trim()||'Variant',items:g.items.map(x=>({val:(x.val||'').trim(),qty:Number(x.qty)||0,photo:(typeof x.photo==='string'&&!__isBlobUrl(x.photo))?x.photo:''})).filter(x=>x.val)})).filter(g=>g.items.length):[];const sizesGroup=cleanGroups.find(g=>/size/i.test(g.name));const colorsGroup=cleanGroups.find(g=>/colou?r/i.test(g.name));const qty=variantMode==='variants'?cleanGroups.reduce((s,g)=>s+g.items.reduce((s2,x)=>s2+(Number(x.qty)||0),0),0):(Number(simpleQty)||0);const cleanPhotos=(photos||[]).filter(u=>typeof u==='string'&&!__isBlobUrl(u));const payload={code:currentCode,name,description:document.getElementById('f-desc').value.trim(),category:selectedCategory,price,cost_price:costPrice,qty,currency:selectedCurrency,comm_pct:finalPct,comm_fixed:comm,comm_mode:commMode,platform_fee:platform,total_fee_per_unit:total,variant_groups:cleanGroups,sizes:sizesGroup?sizesGroup.items.map(x=>x.val):[],colors:colorsGroup?colorsGroup.items.map(x=>x.val):[],delivery:validZones,photos:cleanPhotos,biz_name:(typeof BUSINESS!=='undefined'?BUSINESS.name:null)};if(editingId)payload.id=editingId;console.log('[Lateen] payload ready',payload);if(btn)btn.textContent='Saving…';let __codeLen=6,__saveAttempt=0,__saved=false;while(!__saved){try{await window.LateenAPI.upsertProduct(payload);__saved=true;}catch(__err){const __isDupCode=!editingId&&__err&&(__err.code==='23505'||/duplicate key|unique constraint/i.test(__err.message||''));if(__isDupCode&&__saveAttempt<8){__saveAttempt++;if(__saveAttempt>=4)__codeLen=7;currentCode=genCode(__codeLen);payload.code=currentCode;const __cd=document.getElementById('product-code-display');if(__cd)__cd.textContent=currentCode;continue;}throw __err;}}closeForm();await loadProducts();}catch(e){console.error('[Lateen] upsertProduct',e);alert('Could not save product: '+(e.message||e));}finally{__submittingProduct=false;if(btn){btn.disabled=false;btn.style.opacity='';btn.style.pointerEvents='';if(btn.dataset.origText){btn.textContent=btn.dataset.origText;delete btn.dataset.origText;}}}}
async function toggleStatus(id){const p=products.find(x=>x.id===id);if(!p)return;const next=p.status==='active'?'paused':'active';try{await window.LateenAPI.setStatus(id,next);await loadProducts();}catch(e){console.error(e);alert('Failed to update status');}}
async function deleteProduct(id){if(__frozenBlock())return;if(!confirm('Delete this product? Marketers will no longer see it.'))return;try{await window.LateenAPI.deleteProduct(id);await loadProducts();}catch(e){console.error(e);alert('Failed to delete');}}
function editProduct(id){if(__frozenBlock())return;editingId=id;const p=products.find(x=>x.id===id);if(p)openAddForm(p);}
function filterProducts(){renderProducts();}
function renderProducts(){
  const el=document.getElementById('product-list');
  if(!el)return;
  const si=document.getElementById('products-search');
  const q=(si&&si.value||'').trim().toLowerCase();
  let list=products;
  if(mpActiveFilter==='active')list=list.filter(p=>p.status==='active');
  else if(mpActiveFilter==='paused')list=list.filter(p=>p.status!=='active');
  else if(mpActiveFilter==='lowstock')list=list.filter(p=>{const eq=__mpEffectiveQty(p);return eq>0&&eq<=LOW_STOCK_THRESHOLD;});
  else if(mpActiveFilter==='outofstock')list=list.filter(p=>__mpEffectiveQty(p)<=0);
  if(q){
    list=list.filter(p=>{
      const cities=Object.keys(p.delivery||{}).flatMap(c=>Object.keys((p.delivery[c]&&p.delivery[c].cities)||{}));
      const hay=[p.name,p.code,(p.currency&&p.currency.code)||'',(p.currency&&p.currency.name)||'',...cities].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(q);
    });
  }
  if(!products.length){el.innerHTML='<div class="mp-empty-state">No products yet.</div>';return;}
  if(!list.length){el.innerHTML='<div class="mp-empty-state">No products match your search.</div>';return;}
  el.innerHTML=list.map(mpRenderCard).join('');
  list.forEach(p=>mpInitSwipe(p.id));
}

/* Orders */
const ST={pending:{label:'Pending',step:0,dot:'#E24B4A'},approved:{label:'Approved',step:0,dot:'#EF9F27'},confirmed:{label:'Confirmed',step:1,dot:'#EF9F27'},delivered:{label:'Delivered',step:2,dot:'#34c77b'},failed:{label:'Failed',step:-1,dot:'#e07070'},rejected:{label:'Rejected',step:-1,dot:'#e07070'}};
const STEPS=['New','Confirmed','Delivered'];
const fmt=(n,sym,code)=>__moneyH(n,sym,code);
let activeFilter='all',expandedId=null;
let orders=[];
// Minimal (marketerId, productId, _status:'pending', _createdAt) stubs for
// this business's own pending orders. RLS deliberately keeps full pending
// order rows out of `orders` (unverified receipts stay hidden from the
// business until admin approves), so without these stubs a marketer whose
// only order is still pending would never be counted as "active" here —
// even though the marketer app's live active_marketers_count(s) RPC (which
// bypasses that same RLS) already counts them. Fetched via a narrow
// SECURITY DEFINER RPC that returns nothing but these three fields.
let __pendingActiveStubs=[];
async function loadPendingActiveStubs(){
  if(!window.LateenAPI||!window.LateenAPI.pendingActiveOrdersForBusiness)return;
  try{
    const rows=await window.LateenAPI.pendingActiveOrdersForBusiness();
    __pendingActiveStubs=(rows||[]).map(r=>({marketerId:r.marketer_id,productId:r.product_id,_status:'pending',_createdAt:new Date(r.created_at)}));
  }catch(e){console.error('[Lateen] loadPendingActiveStubs',e);}
}
function dbStatusToUi(s){if(s==='confirmed')return'confirmed';if(s==='delivered')return'delivered';if(s==='cancelled')return'failed';if(s==='rejected')return'rejected';if(s==='approved')return'approved';return'pending';}
function dbToOrder(r){const curCode=(r.currency&&r.currency.code)||'USD';const sym=__wrapArSym((r.currency&&r.currency.symbol)||'$',curCode);const prod=products.find(p=>p.id===r.product_id);const ph=prod&&prod.photos&&prod.photos.length?prod.photos:[(prod&&prod.currency&&prod.currency.flag)||'📦'];const dt=new Date(r.created_at);const d=dt.getDate()+' '+dt.toLocaleString('en',{month:'short'})+' '+dt.getFullYear();const q=Number(r.qty)||1;const shipping=Number(r.shipping_fee)||0;const delivery=Number(r.delivery_fee)||0;const total=Number(r.unit_price)*q+shipping+delivery;const mc=r.marketer_confirmed_at?new Date(r.marketer_confirmed_at):null;const mcDate=mc?(mc.getDate()+' '+mc.toLocaleString('en',{month:'short'})+' '+mc.getFullYear()):'';return{id:'#'+r.id.slice(0,8).toUpperCase(),dbId:r.id,marketerId:r.marketer_id||'',productId:r.product_id||'',source:'affiliate',paymentType:'upfront',paymentAmount:Number(r.commission)*q+Number(r.platform_fee)*q,paymentDate:d,photos:ph,productEmoji:'📦',customerName:r.customer_name||'',customerPhone:r.customer_phone||'',customerWhatsapp:r.customer_whatsapp||'',country:r.customer_country||'',city:r.customer_city||'',address:r.customer_address||'',product:prod?prod.name:'(product)',productCode:prod?prod.code:'',sym,curCode,size:r.size||'',color:r.color||'',qty:q,price:Number(r.unit_price)||0,shipping,delivery,total,commission:Number(r.commission)*q,platformFee:Number(r.platform_fee)*q,status:dbStatusToUi(r.status),date:d,notes:r.customer_notes||'',receiptUrl:r.receipt_url||'',marketerConfirmed:!!r.marketer_confirmed_at,marketerConfirmedDate:mcDate,_createdAt:dt,_status:r.status,_updatedAt:r.updated_at?new Date(r.updated_at):dt};}
async function loadOrders(){if(!window.LateenAPI)return;let rows=[];try{rows=await window.LateenAPI.listMyOrders();}catch(e){console.error('[Lateen] loadOrders fetch',e);}try{orders=(rows||[]).filter(r=>r&&r.business_id).map(dbToOrder);orders.sort((a,b)=>{const at=(a._updatedAt instanceof Date?a._updatedAt:new Date(a._updatedAt||0)).getTime();const bt=(b._updatedAt instanceof Date?b._updatedAt:new Date(b._updatedAt||0)).getTime();return bt-at;});}catch(e){console.error('[Lateen] loadOrders map',e);orders=orders||[];}await loadPendingActiveStubs();try{updateSummary();}catch(e){console.error('[Lateen] updateSummary',e);}try{applyFilters();}catch(e){console.error('[Lateen] applyFilters',e);try{renderOrders([]);}catch(_){}}try{recomputeAnalytics();}catch(e){console.error('[Lateen] recomputeAnalytics',e);}try{if(typeof renderProducts==='function'&&document.getElementById('pg-products')?.classList.contains('active'))renderProducts();}catch(e){}}
const __DOW=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const __MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function __buildSeries(){
  const now=new Date();const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  let earliest=null;orders.forEach(o=>{const c=o._createdAt;if(c&&(!earliest||c<earliest))earliest=c;});
  const minDayStart=new Date(today);minDayStart.setDate(today.getDate()-29);
  let dayStart=earliest?new Date(earliest.getFullYear(),earliest.getMonth(),earliest.getDate()):new Date(today);
  if(dayStart>minDayStart)dayStart=minDayStart;
  const dayCount=Math.floor((today-dayStart)/86400000)+1;
  const minYear=now.getFullYear()-5;const startYear=earliest?Math.min(earliest.getFullYear(),minYear):minYear;
  const endYear=now.getFullYear();const yearCount=endYear-startYear+1;
  const monthsStart=new Date(startYear,0,1);const monthCount=(endYear-startYear)*12+now.getMonth()+1;
  const dayLabels=[],daySub=[];
  for(let i=0;i<dayCount;i++){const d=new Date(dayStart);d.setDate(dayStart.getDate()+i);dayLabels.push(__DOW[d.getDay()]);daySub.push(__ddmmyyyy(d));}
  const monLabels=[],monSub=[];
  for(let i=0;i<monthCount;i++){const m=new Date(monthsStart);m.setMonth(monthsStart.getMonth()+i);monLabels.push(__MON[m.getMonth()]);monSub.push(String(m.getFullYear()));}
  const yrLabels=[],yrSub=[];for(let i=0;i<yearCount;i++){yrLabels.push(String(startYear+i));yrSub.push('');}
  return{dayStart,dayCount,monthsStart,monthCount,startYear,yearCount,dayLabels,daySub,monLabels,monSub,yrLabels,yrSub};
}
function recomputeAnalytics(){
  const s=__buildSeries();
  const revD=Array(s.dayCount).fill(0),revM=Array(s.monthCount).fill(0),revY=Array(s.yearCount).fill(0);
  const pcsD=Array(s.dayCount).fill(0),pcsM=Array(s.monthCount).fill(0),pcsY=Array(s.yearCount).fill(0);
  const ringD={ok:0,fail:0},ringM={ok:0,fail:0},ringY={ok:0,fail:0};
  let totGross=0,totPieces=0,totOk=0,totFail=0,totComm=0,totPlat=0;const marketerSet=new Set();
  orders.concat(__pendingActiveStubs||[]).forEach(o=>{
    const st=o._status;const c=o._createdAt;if(!c)return;
    const net=(o.price*o.qty)-o.commission-o.platformFee;
    const isOk=st==='delivered';const isFail=st==='cancelled';
    if(isOk){totGross+=o.price*o.qty;totPieces+=o.qty;totComm+=o.commission;totPlat+=o.platformFee;totOk++;}
    if(isFail)totFail++;
    if(o.marketerId&&__ACTIVE_MKT_STATUSES.has(st))marketerSet.add(o.marketerId);
    const di=Math.floor((new Date(c.getFullYear(),c.getMonth(),c.getDate())-s.dayStart)/86400000);
    if(di>=0&&di<s.dayCount){if(isOk){revD[di]+=net;pcsD[di]+=o.qty;ringD.ok++;}if(isFail)ringD.fail++;}
    const mi=(c.getFullYear()-s.startYear)*12+c.getMonth();
    if(mi>=0&&mi<s.monthCount){if(isOk){revM[mi]+=net;pcsM[mi]+=o.qty;ringM.ok++;}if(isFail)ringM.fail++;}
    const yi=c.getFullYear()-s.startYear;
    if(yi>=0&&yi<s.yearCount){if(isOk){revY[yi]+=net;pcsY[yi]+=o.qty;ringY.ok++;}if(isFail)ringY.fail++;}
  });
  chartData.revenue.D={labels:s.dayLabels,sub:s.daySub,values:revD.map(v=>+v.toFixed(2))};
  chartData.revenue.M={labels:s.monLabels,sub:s.monSub,values:revM.map(v=>+v.toFixed(2))};
  chartData.revenue.Y={labels:s.yrLabels,sub:s.yrSub,values:revY.map(v=>+v.toFixed(2))};
  chartData.pieces.D={labels:s.dayLabels,sub:s.daySub,values:pcsD};
  chartData.pieces.M={labels:s.monLabels,sub:s.monSub,values:pcsM};
  chartData.pieces.Y={labels:s.yrLabels,sub:s.yrSub,values:pcsY};
  [['D',ringD],['M',ringM],['Y',ringY]].forEach(([k,r])=>{analyticsData[k]={ok:r.ok,fail:r.fail};});
  const set=(id,v)=>{const el=document.getElementById(id);if(el)el.innerHTML=v;};
  const totDone=totOk+totFail;
  set('stat-gross',__moneyH(totGross,'$','USD'));set('stat-pieces',totPieces.toLocaleString());set('stat-pieces-sub','out of '+products.length+' product'+(products.length===1?'':'s'));set('stat-ok',totOk.toLocaleString());set('stat-ok-sub',totDone>0?Math.round(totOk/totDone*100)+'%':'0%');set('stat-fail',totFail.toLocaleString());set('stat-fail-sub',totDone>0?Math.round(totFail/totDone*100)+'%':'0%');set('stat-marketers',marketerSet.size.toLocaleString());set('brk-gross',__moneyH(totGross,'$','USD'));set('brk-comm','−'+__moneyH(totComm,'$','USD'));set('brk-plat','−'+__moneyH(totPlat,'$','USD'));set('brk-net',__moneyH(totGross-totComm-totPlat,'$','USD'));
  __bdAllTime={earnings:totGross-totComm-totPlat,pieces:totPieces,marketers:marketerSet.size,succeeded:totOk,failed:totFail};
  if(typeof buildMainChart==='function')buildMainChart();if(typeof buildRingChart==='function')buildRingChart();if(typeof bdRenderBreakdown==='function')bdRenderBreakdown();
}
function setFilter(f,el){activeFilter=f;document.querySelectorAll('.fchip').forEach(c=>c.classList.remove('active'));el.classList.add('active');applyFilters();}
function applyFilters(){const q=(document.getElementById('search-input')?document.getElementById('search-input').value||'':'').toLowerCase();const list=orders.filter(o=>{const mf=activeFilter==='all'||(activeFilter==='new'&&(o.status==='pending'||o.status==='approved'))||(activeFilter==='failed'&&(o.status==='failed'||o.status==='rejected'))||(activeFilter!=='new'&&activeFilter!=='failed'&&o.status===activeFilter);const s=x=>String(x||'').toLowerCase();const mq=!q||s(o.id).includes(q)||s(o.customerName).includes(q)||s(o.city).includes(q)||s(o.product).includes(q)||s(o.customerPhone).includes(q);return mf&&mq;});renderOrders(list);}
function updateSummary(){const nc=orders.filter(o=>o.status==='pending'||o.status==='approved').length;const fc=orders.filter(o=>o.status==='failed'||o.status==='rejected').length;const banner=document.getElementById('new-banner');if(banner)banner.style.display=nc>0?'flex':'none';const bt=document.getElementById('new-banner-text');if(bt)bt.textContent=nc+' new';const fcNew=document.getElementById('fc-new');const newLbl=__ar()?'جديد':'New';if(fcNew)fcNew.innerHTML=nc>0?`${newLbl} (${nc}) <span style="display:inline-block;width:5px;height:5px;border-radius:50%;background:#ef5566;margin-left:3px;vertical-align:middle;animation:blink 1.5s infinite"></span>`:newLbl;const fcFailed=document.getElementById('fc-failed');if(fcFailed)fcFailed.textContent=fc>0?(__ar()?'فشل ('+fc+')':'Failed ('+fc+')'):(__ar()?'فشل':'Failed');}
const __ordCheckIcon=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke="#34d399" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
function computeOrdFin(o){const subtotal=o.total;const commissionPct=subtotal>0?Math.round((o.commission/subtotal)*100):0;const platformPct=Math.round(PLATFORM_FEE_RATE*100);const base=o.price*o.qty;const net=base-o.commission-o.platformFee;const hasDelivery=Number(o.delivery)>0;const hasShipping=Number(o.shipping)>0;let extra=null;if(hasDelivery&&hasShipping){extra={label:'Total delivery and shipping',value:base+Number(o.delivery)+Number(o.shipping)-o.commission-o.platformFee};}else if(hasDelivery){extra={label:'Total with delivery fee',value:base+Number(o.delivery)-o.commission-o.platformFee};}else if(hasShipping){extra={label:'Total with shipping fee',value:base+Number(o.shipping)-o.commission-o.platformFee};}return{subtotal,commissionPct,platformPct,net,extra};}
function buildOrdStepper(s){if(s==='failed')return`<div class="progress-failed">Order failed</div>`;if(s==='rejected')return`<div class="progress-failed">Receipt rejected</div>`;const si=ST[s]?.step??0;let h='<div class="progress">';STEPS.forEach((step,i)=>{h+=`<div class="step${i===si?' active':''}"><div class="bubble"></div><div class="lbl">${step}</div></div>`;if(i<STEPS.length-1)h+=`<div class="line"></div>`;});h+='</div>';return h;}
function buildOrdActions(o){if(o.status==='delivered'||o.status==='failed'){return`<div class="actions"><button class="btn btn-lock" disabled>${o.status==='delivered'?'✓ Delivered':'Failed'}</button></div>`;}if(o.status==='rejected'){return'<div class="actions"></div>';}const frozen=!!(window.__profileData&&window.__profileData.frozen_at);const dis=frozen?' disabled style="opacity:0.45;pointer-events:none;cursor:not-allowed;"':'';let b='';if(o.status==='approved')b+=`<button class="btn btn-confirm"${dis} onclick="event.stopPropagation();advance('${o.id}','confirmed')">Confirm order</button>`;if(o.status==='confirmed')b+=`<button class="btn btn-deliver"${dis} onclick="event.stopPropagation();advance('${o.id}','delivered')">Mark delivered</button>`;if(o.status==='pending'||o.status==='approved'||o.status==='confirmed')b+=`<button class="btn btn-fail"${dis} onclick="event.stopPropagation();advance('${o.id}','failed')">Failed</button>`;return`<div class="actions">${b}</div>`;}
function __askFailNote(){return new Promise(resolve=>{const ar=(typeof __ar==='function')?__ar():(document.documentElement.lang==='ar');const title=ar?'وضع الطلب: فشل':'Mark order as failed';const lbl=ar?'ملاحظات للمسوق (اختياري)':'Notes for the marketer (optional)';const ok=ar?'تأكيد':'Confirm';const cancel=ar?'إلغاء':'Cancel';const ph=ar?'وضح سبب فشل الطلب…':'Explain why this order failed…';const ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';ov.innerHTML=`<div style="background:#1a2030;border-radius:16px;padding:18px;width:100%;max-width:380px;box-shadow:0 10px 40px rgba(0,0,0,0.5)"><div style="font-size:15px;font-weight:600;color:#fff;margin-bottom:6px">${title}</div><div style="font-size:12px;color:#8a96a8;margin-bottom:10px">${lbl}</div><textarea id="__fn_ta" placeholder="${ph}" style="width:100%;min-height:90px;background:#0f1420;border:1px solid #2a3445;border-radius:10px;color:#fff;padding:10px;font-size:13px;font-family:inherit;resize:vertical;box-sizing:border-box"></textarea><div style="display:flex;gap:8px;margin-top:12px;justify-content:flex-end"><button id="__fn_c" style="background:#2a3445;color:#fff;border:0;border-radius:10px;padding:9px 16px;font-size:13px;font-weight:500;cursor:pointer">${cancel}</button><button id="__fn_o" style="background:#e07070;color:#fff;border:0;border-radius:10px;padding:9px 16px;font-size:13px;font-weight:600;cursor:pointer">${ok}</button></div></div>`;document.body.appendChild(ov);const cleanup=v=>{try{document.body.removeChild(ov);}catch(_){}resolve(v);};ov.querySelector('#__fn_c').onclick=()=>cleanup(null);ov.querySelector('#__fn_o').onclick=()=>{const v=(ov.querySelector('#__fn_ta').value||'').trim();cleanup(v||'');};ov.addEventListener('click',e=>{if(e.target===ov)cleanup(null);});setTimeout(()=>{const ta=ov.querySelector('#__fn_ta');if(ta)ta.focus();},50);});}
async function advance(id,ns){if(__frozenBlock())return;const o=orders.find(x=>x.id===id);if(!o)return;let failNote=null;if(ns==='failed'){const entered=await __askFailNote();if(entered===null)return;failNote=entered||null;}try{if(window.LateenAPI&&o.dbId){if(ns==='confirmed')await window.LateenAPI.confirmOrder(o.dbId);else if(ns==='delivered')await window.LateenAPI.markDelivered(o.dbId);else if(ns==='failed')await window.LateenAPI.markFailed(o.dbId,failNote);}}catch(e){console.error('[Lateen] advance',e);alert('Action failed: '+(e.message||e));return;}await loadProducts();await loadOrders();}
function renderOrders(list){const el=document.getElementById('orders-list');if(!el)return;list=Array.isArray(list)?list:[];if(!list.length){el.innerHTML='<div class="empty-state">No orders found.</div>';return;}el.innerHTML=list.map(o=>{try{const om=n=>fmt(n,o.sym,o.curCode);const isExp=expandedId===o.id;const isImg=s=>typeof s==='string'&&/^(data:|https?:|\/)/.test(s);const photos=(o.photos&&o.photos.length)?o.photos:[o.productEmoji||'📦'];const heroSlides=photos.map(p=>isImg(p)?`<div class="hero-slide"><img src="${p}" alt="" loading="eager" decoding="async"/></div>`:`<div class="hero-slide">${p}</div>`).join('');const heroDots=photos.length>1?`<div class="hero-dots">${photos.map((_,i)=>`<div class="d${i===0?' active':''}"></div>`).join('')}</div>`:'';const stLbl=(ST[o.status]||{}).label||o.status;const __isNewBucket=(o.status==='pending'||o.status==='approved');const __newOrderLbl=__ar()?'طلب جديد':'New order';const statusTag=__isNewBucket?`<div class="status-tag tag-new"><span class="dot"></span>${__newOrderLbl}</div>`:`<div class="status-tag tag-plain ${o.status}">${stLbl}</div>`;const __prodForVariant=(typeof products!=='undefined'&&products)?products.find(p=>p.id===o.productId):null;let variantImg='';let variantLabel=o.size?'Size':(o.color?'Colour':'');if(__prodForVariant&&Array.isArray(__prodForVariant.variantGroups)){outer:for(const g of __prodForVariant.variantGroups){for(const it of(g.items||[])){if(it&&(it.val===o.size||it.val===o.color)){if(g.name)variantLabel=g.name;if(it.photo){variantImg=it.photo;break outer;}}}}}const variantThumb=variantImg?`<div class="variant-thumb" onclick="event.stopPropagation();mpOpenLightbox('${String(variantImg).replace(/'/g,"\\'")}')"><img src="${variantImg}" alt="" loading="lazy"/></div>`:'';const fin=computeOrdFin(o);const codBanner=o.paymentType==='upfront'?`<div class="cod-banner"><div class="icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="7" width="18" height="12" rx="2" stroke="currentColor" stroke-width="1.8"/><path d="M3 10h18" stroke="currentColor" stroke-width="1.8"/></svg></div><div><div class="t1">Cash on delivery</div><div class="t2">Customer pays remaining balance on arrival</div></div></div>`:'';const receiptLink='';return`
      <div class="order-card ${isExp?'expanded':''} ${__isNewBucket?'new':''}" data-status="${o.status}" data-id="${o.id}">
        <div class="card-top" data-action="toggle">
          <div class="photo-wrap">
            <div class="hero-scroll">${heroSlides}</div>
            ${heroDots}
          </div>
          <div class="row-text">
            <div class="row-info">
              <div class="row-name-line">
                <span class="row-name">${o.customerName||'—'}</span>
                <span class="id-badge">${o.id}</span>
              </div>
              <div class="row-sub">${o.product}</div>
            </div>
            <div class="row-right">
              ${o.status==='pending'?statusTag:''}
              <div class="row-amt">${om(o.total)}</div>
              ${o.status==='pending'?'':statusTag}
            </div>
          </div>
        </div>
        <div class="detail-body">
          ${buildOrdStepper(o.status)}
          <div class="section-lbl">Customer &amp; delivery</div>
          <div class="box">
            <div class="r"><span class="k">Name</span><span class="v">${o.customerName}</span></div>
            <div class="r"><span class="k">Address</span><span class="v">${o.address}</span></div>
            <div class="r"><span class="k">City</span><span class="v">${o.city}</span></div>
            <div class="r"><span class="k">Country</span><span class="v">${o.country}</span></div>
            ${(function(){var p=__splitCC(o.customerPhone);return `<div class="r"><span class="k">Phone</span><span class="v phone-val" dir="ltr"><span class="pv-code">${p.cc}</span><span class="pv-divider"></span><span class="pv-num">${p.num}</span></span></div>`;})()}
            ${o.customerWhatsapp?(function(){var w=__splitCC(o.customerWhatsapp);return `<div class="r"><span class="k">WhatsApp</span><span class="v phone-val" dir="ltr"><span class="pv-code">${w.cc}</span><span class="pv-divider"></span><span class="pv-num">${w.num}</span></span></div>`;})():''}
          </div>
          <div class="section-lbl">Order</div>
          <div class="box">
            <div class="r"><span class="k">Order ID</span><span class="v mono">${o.id}</span></div>
            <div class="r"><span class="k">Source</span><span class="v">${o.source==='manual'?'Manual (marketer)':'Affiliate link'}</span></div>
            <div class="r"><span class="k">Product</span><span class="v">${o.product}</span></div>
            <div class="r"><span class="k">Product code</span><span class="v mono">${o.productCode||'—'}</span></div>
            <div class="r"><span class="k">Quantity</span><span class="v">${o.qty}</span></div>
            ${(o.size||o.color)?`<div class="r variant-combo"><span class="k">${variantLabel}</span><div class="v variant-combo-val"><div class="variant-combo-text">${o.size||o.color} <span style="opacity:.65;font-weight:600;">×${o.qty}</span></div>${variantThumb}</div></div>`:''}
          </div>
          <div class="section-lbl">Financials</div>
          <div class="fin-box">
            <div class="fin-row"><span class="k">Product price</span><span class="v">${om(o.price)}</span></div>
            <div class="fin-row"><span class="k">${__ar()?'الكميه':'Quantity'} (${o.qty})</span><span class="v">${om(o.price*o.qty)}</span></div>
            <div class="fin-row"><span class="k">Shipping</span><span class="v">${om(o.shipping)}</span></div>
            <div class="fin-row"><span class="k">Delivery fee</span><span class="v">${om(o.delivery)}</span></div>
            <div class="fin-row"><span class="k">Marketer commission <span class="pct">(${fin.commissionPct}%)</span></span><span class="v neg">−${om(o.commission)}</span></div>
            <div class="fin-row"><span class="k">Platform fee <span class="pct">(${fin.platformPct}%)</span></span><span class="v neg">−${om(o.platformFee)}</span></div>
            <div class="fin-total-extra${fin.extra?' open-capable':''}">
              <div class="fin-total">
                <span class="k">Total</span>
                <span style="display:flex;align-items:center;gap:2px;">
                  <span class="v">${om(fin.net)}</span>
                  ${fin.extra?`<button class="fin-total-arrow" type="button" onclick="event.stopPropagation();this.closest('.fin-total-extra').classList.toggle('open')" aria-label="${fin.extra.label}"><svg class="chev" width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`:''}
                </span>
              </div>
              ${fin.extra?`<div class="fin-total-extra-body"><div class="fin-row" style="border-top:none;padding-top:0;"><span class="k">${fin.extra.label}</span><span class="v">${om(fin.extra.value)}</span></div></div>`:''}
            </div>
          </div>
          <div class="more-info-box">
            <button class="more-info-toggle" type="button" onclick="event.stopPropagation();this.closest('.more-info-box').classList.toggle('open')">
              <span>More info</span>
              <svg class="chev" width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
            <div class="more-info-body">
              <div class="status-box">
                <div class="status-row">${__ordCheckIcon}<span>${o.marketerConfirmed?'Marketer confirmed payment · '+o.marketerConfirmedDate:'Awaiting marketer confirmation · '+o.date}</span></div>
                <div class="status-divider"></div>
                <div class="status-row">${__ordCheckIcon}<span>Upfront fee paid</span><span class="val">${om(o.paymentAmount)}</span></div>
              </div>
              ${codBanner}
            </div>
          </div>
          ${o.notes?`<div class="notes-box">${o.notes}</div>`:''}
          ${receiptLink}
          ${buildOrdActions(o)}
        </div>
      </div>`;}catch(err){console.error('[Lateen] renderOrders item',err,o);return '';}}).join('');el.querySelectorAll('.hero-scroll').forEach(scroller=>{let t;scroller.addEventListener('scroll',()=>{clearTimeout(t);t=setTimeout(()=>{const idx=Math.round(scroller.scrollLeft/(scroller.clientWidth||1));const dots=scroller.parentElement.querySelectorAll('.hero-dots .d');dots.forEach((d,i)=>d.classList.toggle('active',i===idx));},60);});});}
function toggle(id){expandedId=expandedId===id?null:id;applyFilters();}
document.addEventListener('click',function(e){const t=e.target.closest('[data-action="toggle"]');if(t){const card=t.closest('.order-card');if(card)toggle(card.dataset.id);}});

recomputeAnalytics();

/* ── Live data init ── */
let __unsubOrders=null,__unsubWallet=null;
async function refreshWallet(){/* business net earnings come from delivered orders via recomputeAnalytics; nothing to fetch here */}
window.__profileData=null;
function __avKey(){try{return 'lateen_avatar_url_b';}catch(e){return null;}}
function __avCache(url){try{if(url)localStorage.setItem(__avKey(),url);else localStorage.removeItem(__avKey());}catch(e){}}
function __avRead(){try{return localStorage.getItem(__avKey())||'';}catch(e){return '';}}
function __applyAvatarTo(el,url,initials){if(!el)return;el.style.backgroundImage='';if(url){el.textContent='';const img=document.createElement('img');img.decoding='async';img.loading='eager';img.alt='';img.style.cssText='width:100%;height:100%;object-fit:cover;object-position:center;display:block;border-radius:inherit;';img.onerror=function(){el.textContent=initials||'··';};img.src=url;el.appendChild(img);}else{el.textContent=initials||'··';}}
(function(){try{const c=__avRead();if(c){['user-avatar','user-avatar-p','user-avatar-o','menu-avatar'].forEach(id=>{const el=document.getElementById(id);if(el)__applyAvatarTo(el,c,el.textContent||'··');});}}catch(e){}})();
async function refreshProfile(){if(!window.LateenAPI||!window.LateenAPI.getProfile)return;try{const p=await window.LateenAPI.getProfile();window.__profileData=p;const name=(p&&p.full_name)||'';const biz=(p&&p.business_name)||'';const initials=(biz||name)?((biz||name).split(/\s+/).filter(Boolean).slice(0,2).map(s=>s[0].toUpperCase()).join('')):'··';const first=name?name.split(/\s+/)[0]:(__ar()?'يا هلا':'there');const __biz=__ar()?'التاجر':'Business';const __welcome=__ar()?'أهلاً بك':'Welcome';const av=p&&p.avatar_signed_url;__avCache(av||'');['user-avatar','user-avatar-p','user-avatar-o','menu-avatar'].forEach(id=>__applyAvatarTo(document.getElementById(id),av,initials));const g=document.getElementById('user-greet');if(g)g.textContent=(__ar()?'هلا، ':'Hey, ')+first;const s=document.getElementById('user-sub');if(s)s.textContent=biz||__biz;const mn=document.getElementById('menu-name');if(mn)mn.textContent=name||__welcome;const ms=document.getElementById('menu-sub');if(ms)ms.textContent=(biz?biz+' · ':'')+__biz;const frozen=!!(p&&p.frozen_at);const addBtn=document.getElementById('add-product-btn');if(addBtn){addBtn.disabled=frozen;addBtn.style.opacity=frozen?'0.45':'';addBtn.style.pointerEvents=frozen?'none':'';addBtn.style.cursor=frozen?'not-allowed':'';}try{document.body.classList.toggle('lateen-frozen',frozen);}catch(_){}const ar=__ar();const frozenTxt=ar?'تم تجميد الحساب مؤقتاً':'Account temporarily frozen';const banner=document.getElementById('net-frozen-banner');if(banner){banner.style.display=frozen?'block':'none';banner.textContent=frozenTxt;}}catch(e){console.error('[Lateen] profile',e);}}
function __frozenBlock(){const p=window.__profileData;if(p&&p.frozen_at){alert(__ar()?'تم تجميد الحساب مؤقتاً':'Account temporarily frozen');return true;}return false;}
function __profT(){const ar=__ar();return{title:ar?'الملف الشخصي':'Profile',name:ar?'الاسم الكامل':'Full name',biz:ar?'اسم المشروع':'Business name',phone:ar?'رقم الهاتف':'Phone number',email:ar?'البريد الإلكتروني':'Email',wa:ar?'واتساب':'WhatsApp',opt:ar?'(اختياري)':'(optional)',save:ar?'حفظ':'Save',saving:ar?'جارٍ الحفظ…':'Saving…',saved:ar?'تم الحفظ':'Saved',hint:ar?'اضغط على أيقونة الكاميرا لتغيير الصورة':'Tap the camera to change photo',tooBig:ar?'الصورة كبيرة جداً (أقصى 5 ميغابايت)':'Image too large (max 5 MB)',uploading:ar?'جارٍ رفع الصورة…':'Uploading photo…'};}
function openProfile(){const t=__profT();const p=window.__profileData||{};const set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v||'';};const setTxt=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};setTxt('prof-title',t.title);setTxt('prof-lbl-name',t.name);setTxt('prof-lbl-biz',t.biz);setTxt('prof-lbl-phone',t.phone);setTxt('prof-lbl-email',t.email);setTxt('prof-lbl-wa',t.wa);setTxt('prof-lbl-wa-opt',t.opt);setTxt('prof-save-txt',t.save);setTxt('prof-avatar-hint',t.hint);set('prof-name',p.full_name);set('prof-biz',p.business_name);set('prof-phone',p.phone);set('prof-email',p.email);set('prof-whatsapp',p.whatsapp);const base=p.business_name||p.full_name||'';const initials=base?base.split(/\s+/).filter(Boolean).slice(0,2).map(s=>s[0].toUpperCase()).join(''):'··';__applyAvatarTo(document.getElementById('prof-avatar'),p.avatar_signed_url,initials);const ov=document.getElementById('profile-overlay');if(ov)ov.classList.add('open');const md=document.getElementById('menu-overlay');if(md)md.classList.remove('open');}
function closeProfile(){const ov=document.getElementById('profile-overlay');if(ov)ov.classList.remove('open');}
async function pickAvatar(inp){const f=inp&&inp.files&&inp.files[0];if(!f)return;const t=__profT();if(f.size>5*1024*1024){alert(t.tooBig);inp.value='';return;}const hint=document.getElementById('prof-avatar-hint');if(hint)hint.textContent=t.uploading;try{const url=await window.LateenAPI.uploadAvatar(f);const av=document.getElementById('prof-avatar');__applyAvatarTo(av,url,'');if(window.__profileData)window.__profileData.avatar_signed_url=url;await refreshProfile();if(hint)hint.textContent=t.hint;}catch(e){console.error(e);alert('Upload failed');if(hint)hint.textContent=t.hint;}finally{inp.value='';}}
async function saveProfile(){const t=__profT();const btn=document.getElementById('prof-save');const txt=document.getElementById('prof-save-txt');const name=(document.getElementById('prof-name')||{}).value||'';const biz=(document.getElementById('prof-biz')||{}).value||'';const wa=(document.getElementById('prof-whatsapp')||{}).value||'';const patch={full_name:name.trim()||null,business_name:biz.trim()||null,whatsapp:wa.trim()||null};if(btn){btn.disabled=true;btn.style.opacity='.7';}if(txt)txt.textContent=t.saving;try{await window.LateenAPI.updateProfile(patch);await refreshProfile();if(txt)txt.textContent=t.saved;setTimeout(()=>{if(txt)txt.textContent=t.save;if(btn){btn.disabled=false;btn.style.opacity='1';}closeProfile();},700);}catch(e){console.error(e);alert('Save failed');if(txt)txt.textContent=t.save;if(btn){btn.disabled=false;btn.style.opacity='1';}}}
// Override recomputeAnalytics' wallet display: net earnings per currency from delivered orders
window.__bizSelectWalletCur=function(c){window.__bizWalletCur=c;recomputeAnalytics();};
window.__bizSelSym=function(){const e=window.__bizEarnByCur||{};const k=window.__bizWalletCur||Object.keys(e)[0]||'LYD';return (e[k]&&e[k].sym)||'د.ل';};
function __ensureBizBreakdownDiv(){let wb=document.getElementById('biz-wallet-breakdown');if(wb)return wb;const sub=document.querySelector('.bal-sub');if(!sub)return null;wb=document.createElement('div');wb.id='biz-wallet-breakdown';wb.style.cssText='display:none;margin:8px 0 14px 0;padding:10px 12px;border-radius:12px;background:#141414;border:0.5px solid #232323;font-size:11px;color:rgba(255,255,255,0.7);line-height:1.6';sub.insertAdjacentElement('afterend',wb);return wb;}
window.__toggleBizWalletCurList=function(){const l=document.getElementById('biz-wallet-cur-list');const c=document.getElementById('biz-wallet-cur-caret');if(!l)return;const open=l.style.display!=='none';l.style.display=open?'none':'block';if(c)c.style.transform=open?'rotate(0deg)':'rotate(180deg)';};
const __origRecompute=recomputeAnalytics;
recomputeAnalytics=function(){
  __origRecompute.apply(this,arguments);
  try{
    const byCur={};
    orders.forEach(o=>{
      if(o._status!=='delivered')return;
      const code=o.curCode||'USD';const sym=o.sym||'$';
      if(!byCur[code])byCur[code]={sym,gross:0,comm:0,plat:0,net:0};
      const gross=(Number(o.price)||0)*(Number(o.qty)||0);
      const comm=Number(o.commission)||0;
      const plat=Number(o.platformFee)||0;
      byCur[code].gross+=gross;byCur[code].comm+=comm;byCur[code].plat+=plat;byCur[code].net+=gross-comm-plat;
    });
    window.__bizEarnByCur=byCur;Object.keys(byCur).forEach(k=>{byCur[k].amount=byCur[k].net;});
    const codes=Object.keys(byCur);if(!window.__bizWalletCur||!byCur[window.__bizWalletCur])window.__bizWalletCur=codes[0]||'LYD';
    const sel=window.__bizWalletCur;const sd=byCur[sel]||{sym:'د.ل',gross:0,comm:0,plat:0,net:0};
    const wa=document.querySelector('.wallet-amount');if(wa)wa.innerHTML=__moneyH(sd.net,sd.sym,sel);
    const setH=(id,html)=>{const e=document.getElementById(id);if(e)e.innerHTML=html;};
    setH('stat-gross',__moneyH(sd.gross,sd.sym,sel));
    setH('brk-gross',__moneyH(sd.gross,sd.sym,sel));
    setH('brk-comm','−'+__moneyH(sd.comm,sd.sym,sel));
    setH('brk-plat','−'+__moneyH(sd.plat,sd.sym,sel));
    setH('brk-net',__moneyH(sd.net,sd.sym,sel));
    const wb=__ensureBizBreakdownDiv();
    if(wb){
      if(codes.length>1){
        wb.style.display='block';const prev=document.getElementById('biz-wallet-cur-list');const wasOpen=prev&&prev.style.display!=='none';
        const rows=codes.map(c=>{const a=c===sel;return `<button data-no-i18n onclick="__bizSelectWalletCur('${c}')" style="display:flex;align-items:center;justify-content:space-between;gap:8px;width:100%;margin:0 0 6px 0;padding:10px 12px;border-radius:10px;border:0.5px solid ${a?'#7f77dd':'#232323'};background:${a?'#1a1830':'#0f0f0f'};color:#fff;font-size:12px;cursor:pointer;font-family:inherit;text-align:left"><span style="display:inline-flex;align-items:center;gap:8px"><span style="opacity:0.7">${__rawSym(byCur[c].sym,c)}</span><span>${c}</span></span><span style="font-weight:500">${__moneyH(byCur[c].net,byCur[c].sym,c)}</span></button>`;}).join('');
        wb.innerHTML=`<button data-no-i18n onclick="__toggleBizWalletCurList()" style="display:flex;align-items:center;justify-content:space-between;width:100%;padding:9px 12px;border-radius:10px;border:0.5px solid #232323;background:#141414;color:#fff;font-size:11px;cursor:pointer;font-family:inherit"><span style="display:inline-flex;align-items:center;gap:8px"><span style="opacity:0.55;letter-spacing:0.04em">NET EARNINGS BY CURRENCY</span><span style="opacity:0.5">·</span><span style="opacity:0.85">${codes.length} currencies</span></span><span id="biz-wallet-cur-caret" style="display:inline-block;transition:transform .15s;opacity:0.7">▾</span></button><div id="biz-wallet-cur-list" style="display:${wasOpen?'block':'none'};margin-top:8px">${rows}</div>`;
        const caret=document.getElementById('biz-wallet-cur-caret');if(caret&&wasOpen)caret.style.transform='rotate(180deg)';wb.style.background='transparent';wb.style.border='none';wb.style.padding='0';
      }else{wb.style.display='none';wb.innerHTML='';}
    }
  }catch(e){console.error('[Lateen] biz wallet',e);}
};
(async()=>{try{await loadProducts();await loadOrders();await refreshProfile();}catch(e){console.error('[Lateen] business boot',e);}})();
window.__lateenUnsubs=window.__lateenUnsubs||[];if(window.LateenAPI&&window.LateenAPI.subscribe){
  /* Coalesce bursts of realtime events into a single refresh so the list
     doesn't rebuild multiple times back-to-back (which caused visible
     flicker / momentary blanking on create). */
  let __rtTimer=null;const __refreshSoon=()=>{if(__rtTimer)return;__rtTimer=setTimeout(()=>{__rtTimer=null;loadProducts();loadOrders();},180);};
  window.__lateenUnsubs.push(window.LateenAPI.subscribe('my-products',__refreshSoon));
  window.__lateenUnsubs.push(window.LateenAPI.subscribe('orders',__refreshSoon));
}
/* Signature-based render skip: if the exact same list would be rendered
   again, don't touch innerHTML at all — that removes the "list vanishes and
   reappears" flash when realtime fires right after a local mutation. */
(function(){
  const _rp=window.renderProducts;let __sigP='';
  if(typeof _rp==='function'){window.renderProducts=function(){try{const s=JSON.stringify((products||[]).map(p=>[p.id,p.status,p.qty,p.name,p.price,(p.photos||[]).length,(p.updated_at||'')]));if(s===__sigP)return;__sigP=s;}catch(e){}return _rp.apply(this,arguments);};}
  const _ro=window.renderOrders;let __sigO='';
  if(typeof _ro==='function'){window.renderOrders=function(list){try{const s=JSON.stringify((list||[]).map(o=>[o.id,o.status,o.qty,o.receiptUrl,o.marketerConfirmed]));if(s===__sigO)return;__sigO=s;}catch(e){}return _ro.apply(this,arguments);};}
})();
/* persist page + scroll across refresh */
(function(){const K='lateen_bz_page',S='lateen_bz_scroll';const _g=goTo;goTo=function(id){try{sessionStorage.setItem(K,id);}catch(e){}return _g.apply(this,arguments);};try{const sv=sessionStorage.getItem(K);if(sv&&document.getElementById(sv))_g(sv);const sc=parseInt(sessionStorage.getItem(S)||'0',10);if(sc>0)requestAnimationFrame(()=>window.scrollTo(0,sc));}catch(e){}window.addEventListener('scroll',()=>{try{sessionStorage.setItem(S,String(window.scrollY||0));}catch(e){}},{passive:true});})();

/* auto-hide bottom nav on scroll down, show on scroll up */
(function(){const nav=document.querySelector('.lateen-business .bottom-nav');if(!nav)return;let lastY=window.scrollY||0,ticking=false;const TH=6;function upd(){const y=window.scrollY||0,d=y-lastY;if(Math.abs(d)>TH){if(d>0&&y>60)nav.classList.add('nav-hidden');else nav.classList.remove('nav-hidden');lastY=y;}ticking=false;}window.addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(upd);ticking=true;}},{passive:true});})();

/* ── Notifications ── */
let __bizNotifNewIds = (window.__bizNotifNewIds instanceof Set) ? window.__bizNotifNewIds : new Set();
window.__bizNotifNewIds = __bizNotifNewIds;
window.__bizReviewsByProduct = window.__bizReviewsByProduct || {};
async function refreshBizNotifications(){
  if(!window.LateenAPI||!window.LateenAPI.listNotifications)return;
  let list=[];try{list=await window.LateenAPI.listNotifications();}catch(e){return;}
  /* Build review map from notifications so reviews show in product cards */
  const rmap={};
  for(const n of list){
    if(n.kind!=='product_review')continue;
    let d=n.data;if(typeof d==='string'){try{d=JSON.parse(d);}catch(e){d=null;}}
    if(!d||!d.product_id)continue;
    (rmap[d.product_id]=rmap[d.product_id]||[]).push({author:d.author||'Marketer',rating:Number(d.rating)||0,text:d.text||'',ts:new Date(n.created_at).getTime()});
  }
  window.__bizReviewsByProduct=rmap;
  try{if(typeof renderProducts==='function'&&document.getElementById('pg-products')?.classList.contains('active'))renderProducts();}catch(e){}
  const dot=document.getElementById('notif-dot');
  const onNotifPage=document.getElementById('pg-notif')&&document.getElementById('pg-notif').classList.contains('active');
  if(dot)dot.style.display=(!onNotifPage&&list.some(n=>!n.read_at))?'block':'none';
  const root=document.getElementById('notif-list');
  if(!root)return;
  const tr=(en,ar)=>__ar()?ar:en;
  if(!list.length){root.innerHTML='<div style="padding:60px 20px;text-align:center;color:var(--color-text-secondary);font-size:13px;">'+tr('No notifications yet.','لا توجد إشعارات بعد.')+'</div>';return;}
  const ago=(t)=>{const s=Math.max(1,Math.floor((Date.now()-new Date(t).getTime())/1000));const ar=__ar();if(s<60)return ar?s+'ث':s+'s';if(s<3600)return ar?Math.floor(s/60)+'د':Math.floor(s/60)+'m';if(s<86400)return ar?Math.floor(s/3600)+'س':Math.floor(s/3600)+'h';return ar?Math.floor(s/86400)+'يوم':Math.floor(s/86400)+'d';};
  const esc=(s)=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  root.innerHTML=list.map(n=>{
    let t=n.title,b=n.body||'';
    if(n.kind==='new_order'||t==='New order'){t=tr('New order','طلب جديد');b=tr('A new order has been received. Check the Orders page.','وصلك طلب جديد. راجع صفحة الطلبات.');}
    let reviewDetails='';
    if(n.kind==='product_review'){
      let d=n.data;if(typeof d==='string'){try{d=JSON.parse(d);}catch(e){d=null;}}
      const author=(d&&d.author)||'Marketer';
      const pname=(d&&d.product_name)||'';
      const rating=Number(d&&d.rating)||0;
      t=tr('New product review','تقييم جديد للمنتج');
      b=__ar()
        ? `${author} قيّم المنتج ${pname} ${rating} ${rating===1?'نجمة':'نجوم'}`
        : `${author} rated ${pname} ${rating} ${rating===1?'star':'stars'}`;
      if(d&&d.text){
        const stars='★'.repeat(rating)+'☆'.repeat(Math.max(0,5-rating));
        reviewDetails=`<div style="margin-top:6px;padding:8px 10px;border-radius:8px;background:#181818;border:0.5px solid #232323;font-size:12px;color:var(--color-text-primary)"><div style="color:#e9b949;letter-spacing:2px;margin-bottom:4px">${stars}</div>${esc(d.text)}</div>`;
      }
    }
    const expandable=n.kind==='new_order';
    const color=expandable?'#34c77b':(n.kind==='product_review'?'#e9b949':'#7f77dd');
    let detailsHtml='';
    if(expandable&&n.data){
      let d=n.data;if(typeof d==='string'){try{d=JSON.parse(d);}catch(e){d=null;}}
      if(d){
        const row=(k,v)=>v?`<div style="display:flex;justify-content:space-between;gap:10px;padding:4px 0;font-size:12px"><span style="color:var(--color-text-secondary)">${esc(k)}</span><span style="color:var(--color-text-primary);text-align:right">${esc(v)}</span></div>`:'';
        const photo=d.product_photo&&/^(https?:|data:|\/)/.test(String(d.product_photo))?`<div style="margin:-2px 0 10px 0"><img src="${esc(d.product_photo)}" alt="" style="width:100%;max-height:220px;object-fit:contain;background:#0d0d0d;border-radius:10px;display:block"/></div>`:'';
        detailsHtml=`<div class="notif-details" data-nd="1" style="display:none;margin-top:8px;padding:10px 12px;border-radius:10px;background:#181818;border:0.5px solid #142a20">
          ${photo}
          ${row(tr('Order Code','كود الطلبيه'),d.order_code)}
          ${row(tr('Product','المنتج'),d.product_name)}
          ${row(tr('Qty','الكمية'),d.qty)}
          ${row(tr('Customer','الزبون'),d.customer_name)}
          ${(function(){var p=__splitCC(d.customer_phone);return row(tr('Country code','رمز الدولة'),p.cc)+row(tr('Phone','الهاتف'),p.num);})()}
          ${d.customer_whatsapp?(function(){var w=__splitCC(d.customer_whatsapp);return row(tr('WhatsApp code','رمز واتساب'),w.cc)+row(tr('WhatsApp','واتساب'),w.num);})():''}
          ${row(tr('City','المدينة'),d.customer_city)}
          ${row(tr('Country','الدولة'),d.customer_country)}
          ${row(tr('Address','العنوان'),d.customer_address)}
          ${row(tr('Size','المقاس'),d.size)}
          ${row(tr('Colour','اللون'),d.color)}
          ${d.customer_notes?`<div style="margin-top:6px;padding:8px 10px;border-radius:8px;background:#0f0f0f;color:var(--color-text-secondary);font-size:11px"><b>${tr('Notes','ملاحظات')}:</b> ${esc(d.customer_notes)}</div>`:''}
        </div>`;
      }
    }
    const clickable=expandable&&detailsHtml?' onclick="(function(el){var d=el.querySelector(\'[data-nd]\');if(d)d.style.display=d.style.display===\'none\'?\'block\':\'none\';})(this)" style="cursor:pointer"':'';
    const isNew=!n.read_at;
    const rightDot=isNew?'<div style="width:8px;height:8px;border-radius:50%;background:#E24B4A;flex-shrink:0;margin-top:4px;"></div>':'<div style="width:8px;flex-shrink:0;"></div>';
    return `<div class="notif-item"${clickable}><div class="notif-icon" style="background:${color}22;color:${color}">•</div><div style="flex:1;min-width:0"><div class="notif-title">${esc(t)}</div>${b?`<div class="notif-body">${esc(b)}</div>`:''}${reviewDetails}${detailsHtml}<div class="notif-time">${ago(n.created_at)}</div></div><div style="display:flex;align-items:flex-start;gap:6px;flex-shrink:0;">${rightDot}</div></div>`;
  }).join('');
}
window.refreshBizNotifications=refreshBizNotifications;
(function(){
  const _g=goTo;
  let __lastPage=null;
  goTo=function(id){
    /* When leaving notifications page, immediately hide all red dots in the list, then sync to DB */
    if(__lastPage==='pg-notif'&&id!=='pg-notif'){
      try{const root=document.getElementById('notif-list');if(root){root.querySelectorAll('div').forEach(el=>{const bg=el.style&&el.style.background;if(bg&&bg.indexOf('#E24B4A')!==-1)el.style.display='none';});}}catch(e){}
      (async()=>{try{if(window.LateenAPI&&window.LateenAPI.markNotificationsRead)await window.LateenAPI.markNotificationsRead();}catch(e){}refreshBizNotifications();})();
    }
    __lastPage=id;
    _g.apply(this,arguments);
    if(id==='pg-notif'){refreshBizNotifications();const dot=document.getElementById('notif-dot');if(dot)dot.style.display='none';}
  };
  window.goTo=goTo;
})();
if(window.LateenAPI&&window.LateenAPI.subscribe){window.__lateenUnsubs=window.__lateenUnsubs||[];window.__lateenUnsubs.push(window.LateenAPI.subscribe('notifications',()=>refreshBizNotifications()));}
refreshBizNotifications();

/* Reviews are now rendered directly inside each product card via
   mpReviewsFold(), reading from window.__bizReviewsByProduct. When that
   map is refreshed (see refreshBizNotifications below) we just need to
   re-render the products list so the Reviews fold picks up the latest
   data — renderProducts() already does that on every call. */
