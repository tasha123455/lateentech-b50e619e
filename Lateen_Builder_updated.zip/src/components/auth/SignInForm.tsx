import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { GoogleButton } from "./GoogleButton";
import { useAuth } from "@/auth/AuthContext";
import { useLanguage } from "@/i18n/LanguageContext";

type Role = "marketer" | "business";

const styles = (role: Role) =>
  role === "marketer"
    ? { link: "text-marketer-foreground" }
    : { link: "text-business" };

export function SignInForm({ role }: { role: Role }) {
  const s = styles(role);
  const nav = useNavigate();
  const { loadRoleForUser } = useAuth();
  const { lang } = useLanguage();
  const ar = lang === "ar";
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const msg = sessionStorage.getItem("signin_error");
      if (msg) {
        setError(msg);
        sessionStorage.removeItem("signin_error");
      }
    } catch { /* ignore */ }
  }, []);

  const otherRole: Role = role === "marketer" ? "business" : "marketer";

  const crossRoleMsg = (other: Role) => {
    if (ar) {
      const other_ar_indef = other === "business" ? "تاجر" : "مسوّق";
      const other_ar_def = other === "business" ? "التاجر" : "المسوّق";
      const thisRole_ar = role === "business" ? "تاجر" : "مسوّق";
      return `هذا الحساب مسجل كحساب ${other_ar_indef}. يرجى استخدام صفحة تسجيل الدخول الخاص ب${other_ar_def}، أو إنشاء حساب ${thisRole_ar} منفصل.`;
    }
    return `This account is registered as a ${other}. Please use the ${other} sign-in page, or create a separate ${role} account.`;
  };

  const verifyRole = async (userId: string) => {
    const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId);
    if (error) throw error;
    const roles = (data ?? []).map((r) => r.role as string);
    if (roles.includes("admin")) return "admin" as const;
    if (roles.includes(role)) {
      const { data: prof } = await supabase.from("profiles").select("banned_at").eq("id", userId).maybeSingle();
      if (prof?.banned_at) {
        await supabase.auth.signOut();
        throw new Error(ar ? "هذه الحساب محظور." : "This account is banned.");
      }
      return role;
    }
    if (roles.includes(otherRole)) {
      await supabase.auth.signOut();
      throw new Error(crossRoleMsg(otherRole));
    }
    await supabase.auth.signOut();
    throw new Error(ar ? "لا يوجد حساب موجود بهذا البريد الإلكتروني من جوجل. يرجى إنشاء حساب جديد أولاً." : `No ${role} account found for this user. Please register first.`);
  };

  const signInGoogle = async () => {
    setError(null);
    try { localStorage.setItem("active_role", role); } catch { /* ignore */ }
    try { sessionStorage.setItem("intended_role", role); } catch { /* ignore */ }
    try { sessionStorage.setItem("signin_intent", role); } catch { /* ignore */ }
    try { sessionStorage.removeItem("pending_signup"); } catch { /* ignore */ }
    const { error: oauthError } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: window.location.origin },
    });
    if (oauthError) setError(oauthError.message);
  };

  const subtitle = role === "marketer" ? "Sign in to your marketer account" : "Sign in to your business account";

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm text-text-2">{subtitle}</p>
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
      <GoogleButton onClick={signInGoogle}>Sign in with Google</GoogleButton>
      <p className="text-center text-xs text-text-2">
        New here?{" "}
        <Link to={role === "marketer" ? "/marketer/register" : "/business/register"} className={`font-medium ${s.link}`}>
          Create an account
        </Link>
      </p>
    </div>
  );
}

export function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs text-text-2">
        {label}{required && <span className="ms-1 text-destructive">*</span>}
      </span>
      {children}
    </label>
  );
}

export function Divider() {
  return (
    <div className="flex items-center gap-3 py-1">
      <div className="h-px flex-1 bg-border" />
      <span className="text-[10px] uppercase tracking-wider text-text-3">or</span>
      <div className="h-px flex-1 bg-border" />
    </div>
  );
}
